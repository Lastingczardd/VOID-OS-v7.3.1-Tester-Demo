# VOID OS Φ∞ v7.4 — The Evidence Covenant

**State:** Promising early alpha  
**Operator:** @LastingCzardd / @reson8labs  
**Upgrade mandate:** Make the machinery deserve the myth.

This package upgrades the reviewed v7.3.1 Tester Demo into a runnable
demonstration of a local autonomous engineering institution governed by rights,
evidence, lineage, consent, reversibility, and visible repair.

## Fastest demo: no Ollama required

On Windows, double-click:

```text
START_EVIDENCE_DEMO.bat
```

The demo runs one complete twelve-gate cycle, opens an offline HTML evidence
report, and leaves every artifact under `demo_runs/CYCLE-.../`.

It demonstrates:

- direct observation separated from inference and proposal;
- three materially different options;
- L0–L5 authority checks;
- denial when consent is silent;
- denial beyond the builder-defined ceiling;
- an explicitly approved L2 sandbox change;
- a pre-change snapshot and byte-for-byte rollback proof;
- before/after measurement;
- artifact ancestry;
- five hash-chained institutional ledgers;
- a retained failure → diagnosis → repair → retest chain;
- a claim-to-mechanism matrix showing DECLARED, ENFORCED, or VERIFIED;
- honest limits, including disabled generated-code execution.

No network is used. No model is called. No generated code is executed.

## Full existing VOID OS interface

The v7.3.1 agent, dataset, Ollama, coding, research, plugin, project, and Tkinter
machinery remains included. To launch it on Windows:

```text
START_VOID_OS.bat
```

That path requires Python 3.10+, Tkinter, Ollama, and the configured local models.
The original tester limits remain active: three cycles per START and ten cycles
per installation, with unattended core upgrades disabled.

## Verify the package

Double-click `VERIFY_DEMO.bat`, or run:

```bash
python VERIFY_DEMO.py
```

The verifier:

1. compiles all Python files;
2. runs the unit tests;
3. runs a fresh headless covenant cycle;
4. checks the packaged core integrity manifest.

## Evidence layout

```text
demo_runs/CYCLE-.../
├── EVIDENCE_REPORT.html
├── cycle_summary.json
├── evidence/
│   ├── 01_observation.json
│   ├── ...
│   ├── 12_disposition.json
│   ├── settings.before.json
│   └── restore_probe.json
├── ledgers/
│   ├── observations.jsonl
│   ├── decisions.jsonl
│   ├── artifacts.jsonl
│   ├── incidents.jsonl
│   └── constitution.jsonl
└── sandbox_project/
    └── settings.json
```

## Authority model

| Level | Capability | Demo policy |
|---|---|---|
| L0 | Observe | Autonomous |
| L1 | Propose | Autonomous |
| L2 | Modify sandbox | Explicit approval |
| L3 | Modify project | Beyond demo ceiling |
| L4 | Execute generated code | Disabled |
| L5 | Affect external systems | Disabled |

The demo passes explicit approval internally only for its predefined,
deterministic L2 fixture. That approval cannot authorize L3–L5 actions.

## What this package honestly proves

It proves that the included deterministic governance path exists and is tested:
consent decisions, bounded authority, chained ledgers, evidence classification,
lineage, measurable verification, snapshot restoration, and visible repair.

It does **not** prove that arbitrary generated code can run safely unattended.
The execution chamber remains disabled and is listed as ENFORCED, not VERIFIED.

## Canonical cycle

```text
OBSERVE → INVENTORY → CLASSIFY EVIDENCE → IDENTIFY CLAIM
→ GENERATE DISTINCT OPTIONS → COMPARE CONSEQUENCES
→ CHECK AUTHORITY → REQUEST CONSENT → BUILD IN SANDBOX
→ VERIFY MEASURABLY → RECORD LINEAGE AND REPAIR
→ ACCEPT, REJECT, OR REVERT
```
