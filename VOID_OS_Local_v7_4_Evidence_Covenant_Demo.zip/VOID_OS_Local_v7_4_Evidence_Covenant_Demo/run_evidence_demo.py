"""Run the complete offline Evidence Covenant demonstration."""
from __future__ import annotations

import argparse
import sys
import webbrowser
from pathlib import Path

from void_os.governance.demo_cycle import EvidenceCovenantDemo


def main() -> int:
    parser = argparse.ArgumentParser(description="Run the VOID OS v7.4 Evidence Covenant demo.")
    parser.add_argument("--no-open", action="store_true", help="Do not open the HTML evidence report.")
    parser.add_argument(
        "--output",
        type=Path,
        default=Path(__file__).with_name("demo_runs"),
        help="Directory that receives immutable-style run folders.",
    )
    args = parser.parse_args()
    try:
        result = EvidenceCovenantDemo(args.output).run()
    except Exception as exc:
        print(f"DEMO FAILED: {exc}", file=sys.stderr)
        return 1
    print("\nVOID OS Φ∞ v7.4 — THE EVIDENCE COVENANT")
    print("=" * 52)
    print(f"Cycle:       {result['cycle_id']}")
    print(f"Result:      {result['result']}")
    print("Measurement: duplicate entries 1 -> 0")
    print("Authority:   L4 denied | L5 denied | explicit L2 approved")
    print(
        "Ledgers:     "
        + ", ".join(
            f"{name}={'PASS' if check['passed'] else 'FAIL'}"
            for name, check in result["ledger_checks"].items()
        )
    )
    print(f"Report:      {result['report_path']}")
    if not args.no_open:
        webbrowser.open(Path(result["report_path"]).resolve().as_uri())
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
