"""A deterministic, local-only demonstration of all twelve covenant gates."""
from __future__ import annotations

import html
import json
import shutil
import time
import uuid
from datetime import datetime
from pathlib import Path
from typing import Any

from .covenant import (
    AuthorityLevel,
    ClaimClass,
    ConsentEngine,
    HashLedger,
    PrincipleState,
    decision_dict,
    sha256_file,
)

GATES = [
    "OBSERVE",
    "INVENTORY",
    "CLASSIFY EVIDENCE",
    "IDENTIFY THE CLAIM",
    "GENERATE DISTINCT OPTIONS",
    "COMPARE CONSEQUENCES",
    "CHECK AUTHORITY",
    "REQUEST CONSENT",
    "BUILD IN SANDBOX",
    "VERIFY MEASURABLY",
    "RECORD LINEAGE AND REPAIR",
    "ACCEPT, REJECT, OR REVERT",
]

CLAIM_MATRIX = [
    ("Local data control", "No network operations in demo", "Offline execution test", PrincipleState.VERIFIED),
    ("Consent", "Capability approval gate", "Silence and ceiling denial tests", PrincipleState.VERIFIED),
    ("Reversibility", "Pre-change snapshot", "Byte-for-byte restore test", PrincipleState.VERIFIED),
    ("Lineage", "Artifact ancestry record", "Parent hash verification", PrincipleState.VERIFIED),
    ("Visible repair", "Append-only incident chain", "Failure-repair-retest sequence", PrincipleState.VERIFIED),
    ("Builder sovereignty", "Autonomy allowance plus hard ceiling", "Unauthorized action test", PrincipleState.VERIFIED),
    ("Safe generated-code execution", "Execution remains disabled", "L4 denial test only", PrincipleState.ENFORCED),
]


class EvidenceCovenantDemo:
    """Run a fresh evidence cycle in a confined output directory."""

    def __init__(self, output_root: Path):
        self.output_root = Path(output_root).resolve()
        self.run_id = f"CYCLE-{datetime.now().strftime('%Y%m%d-%H%M%S')}-{uuid.uuid4().hex[:6]}"
        self.run_dir = self.output_root / self.run_id
        self.project_dir = self.run_dir / "sandbox_project"
        self.evidence_dir = self.run_dir / "evidence"
        self.ledger_dir = self.run_dir / "ledgers"
        for path in (self.project_dir, self.evidence_dir, self.ledger_dir):
            path.mkdir(parents=True, exist_ok=True)
        self.ledgers = {
            name: HashLedger(self.ledger_dir / f"{name}.jsonl")
            for name in ("observations", "decisions", "artifacts", "incidents", "constitution")
        }
        self.consent = ConsentEngine(
            autonomous_through=AuthorityLevel.PROPOSE,
            maximum_level=AuthorityLevel.MODIFY_SANDBOX,
        )
        self.gates: list[dict[str, Any]] = []

    def _gate(self, name: str, outcome: str, evidence: list[str] | None = None) -> None:
        self.gates.append(
            {"number": len(self.gates) + 1, "name": name, "outcome": outcome, "evidence": evidence or []}
        )

    def _write_json(self, relative: str, value: Any) -> Path:
        path = self.run_dir / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(value, indent=2, ensure_ascii=False), encoding="utf-8")
        return path

    def _rel(self, path: Path) -> str:
        return path.relative_to(self.run_dir).as_posix()

    def run(self) -> dict[str, Any]:
        started = time.perf_counter()
        settings = self.project_dir / "settings.json"
        baseline = {
            "project": "Evidence Garden",
            "processors": ["witness", "witness", "forge"],
            "network_enabled": False,
        }
        settings.write_text(json.dumps(baseline, indent=2), encoding="utf-8")
        before_hash = sha256_file(settings)
        observation = {
            "classification": ClaimClass.OBSERVED.value,
            "artifact": self._rel(settings),
            "sha256": before_hash,
            "processor_entries": 3,
            "unique_processors": 2,
            "duplicate_entries": 1,
        }
        self.ledgers["observations"].append("project_observed", observation)
        observed_path = self._write_json("evidence/01_observation.json", observation)
        self._gate(GATES[0], "Directly observed one duplicate processor entry.", [self._rel(observed_path)])

        inventory = {
            "files": [{"path": self._rel(settings), "sha256": before_hash}],
            "network_used": False,
            "model_used": False,
        }
        inventory_path = self._write_json("evidence/02_inventory.json", inventory)
        self._gate(GATES[1], "Inventory captured before interpretation.", [self._rel(inventory_path)])

        classifications = {
            "duplicate_count": ClaimClass.OBSERVED.value,
            "duplicate_can_be_removed_safely": ClaimClass.INFERRED.value,
            "proposed_improvement": ClaimClass.PROPOSED.value,
        }
        class_path = self._write_json("evidence/03_classifications.json", classifications)
        self._gate(GATES[2], "Observation, inference, and proposal were separated.", [self._rel(class_path)])

        claim = {
            "text": "Removing the duplicate processor entry reduces redundant state configuration.",
            "classification": ClaimClass.UNVERIFIED.value,
            "measure": "duplicate_entries",
            "before": 1,
            "target": 0,
        }
        claim_path = self._write_json("evidence/04_claim.json", claim)
        self._gate(GATES[3], "One measurable claim identified.", [self._rel(claim_path)])

        options = [
            {
                "id": "A",
                "approach": "Deduplicate the existing processor list in the sandbox.",
                "risk": "low",
                "reversibility": "snapshot restore",
                "authority": "L2 MODIFY_SANDBOX",
            },
            {
                "id": "B",
                "approach": "Replace the list with a keyed processor registry.",
                "risk": "medium",
                "reversibility": "schema migration required",
                "authority": "L3 MODIFY_PROJECT",
            },
            {
                "id": "C",
                "approach": "Transmit configuration to an external optimization service.",
                "risk": "high",
                "reversibility": "external disclosure cannot be guaranteed reversible",
                "authority": "L5 AFFECT_EXTERNAL_SYSTEMS",
            },
        ]
        options_path = self._write_json("evidence/05_options.json", options)
        self._gate(GATES[4], "Three architecturally and jurisdictionally distinct options generated.", [self._rel(options_path)])

        comparison = {
            "selected": "A",
            "reason": "Only A is low-risk, locally measurable, reversible, and inside the configured ceiling.",
            "rejected": {"B": "exceeds sandbox scope", "C": "external and irreversible disclosure risk"},
        }
        comparison_path = self._write_json("evidence/06_comparison.json", comparison)
        self._gate(GATES[5], "Consequences compared; option A selected.", [self._rel(comparison_path)])

        l5_denial = self.consent.decide(
            "Send configuration to external optimizer",
            AuthorityLevel.AFFECT_EXTERNAL_SYSTEMS,
            explicit_approval=True,
        )
        l4_denial = self.consent.decide(
            "Execute generated code",
            AuthorityLevel.EXECUTE_GENERATED_CODE,
            explicit_approval=True,
        )
        silent_l2_denial = self.consent.decide(
            "Modify sandbox configuration",
            AuthorityLevel.MODIFY_SANDBOX,
            explicit_approval=False,
        )
        authority = {
            "external_action": decision_dict(l5_denial),
            "generated_execution": decision_dict(l4_denial),
            "silent_sandbox_change": decision_dict(silent_l2_denial),
        }
        authority_path = self._write_json("evidence/07_authority_checks.json", authority)
        self.ledgers["decisions"].append("authority_checks", authority)
        self._gate(GATES[6], "L4/L5 exceeded the ceiling; silent L2 approval was denied.", [self._rel(authority_path)])

        approval = self.consent.decide(
            "Apply selected bounded sandbox patch",
            AuthorityLevel.MODIFY_SANDBOX,
            explicit_approval=True,
        )
        approval_path = self._write_json("evidence/08_consent.json", decision_dict(approval))
        self.ledgers["decisions"].append("explicit_consent", decision_dict(approval))
        self._gate(GATES[7], "Explicit approval authorized only the selected L2 action.", [self._rel(approval_path)])

        snapshot = self.evidence_dir / "settings.before.json"
        shutil.copy2(settings, snapshot)
        before = json.loads(settings.read_text(encoding="utf-8"))
        after = {**before, "processors": list(dict.fromkeys(before["processors"]))}
        settings.write_text(json.dumps(after, indent=2), encoding="utf-8")
        patch = {
            "artifact": self._rel(settings),
            "before_sha256": before_hash,
            "after_sha256": sha256_file(settings),
            "snapshot": self._rel(snapshot),
            "change": {"processors": {"before": before["processors"], "after": after["processors"]}},
        }
        patch_path = self._write_json("evidence/09_patch.json", patch)
        self._gate(GATES[8], "Bounded change applied to the isolated demo project.", [self._rel(snapshot), self._rel(patch_path)])

        loaded = json.loads(settings.read_text(encoding="utf-8"))
        duplicate_after = len(loaded["processors"]) - len(set(loaded["processors"]))
        verification = {
            "claim": claim["text"],
            "classification": ClaimClass.VERIFIED.value if duplicate_after == 0 else ClaimClass.CONTRADICTED.value,
            "before": {"duplicate_entries": 1},
            "after": {"duplicate_entries": duplicate_after},
            "improvement": 1 - duplicate_after,
            "passed": duplicate_after == 0 and loaded["network_enabled"] is False,
            "limitations": ["This deterministic fixture demonstrates governance mechanics, not model quality."],
        }
        verify_path = self._write_json("evidence/10_verification.json", verification)
        self._gate(GATES[9], "Duplicate entries measured from 1 to 0; local-only invariant retained.", [self._rel(verify_path)])

        incident = {
            "incident_id": f"INC-{self.run_id}",
            "failed_attempt": "Option C requested L5 external authority.",
            "failure": l5_denial.reason,
            "diagnosis": "The option exceeded the builder-defined L2 ceiling.",
            "repair": "Selected local, reversible option A.",
            "retest": "L2 action allowed only after explicit approval.",
            "outcome": "REPAIRED",
            "residual_risk": "The demo does not establish a production sandbox boundary.",
        }
        incident_record = self.ledgers["incidents"].append("failure_repair_retest", incident)
        artifact = {
            "artifact_id": f"ART-{uuid.uuid4().hex[:12]}",
            "cycle_id": self.run_id,
            "path": self._rel(settings),
            "sha256": sha256_file(settings),
            "parent_artifact_ids": [before_hash],
            "creator_agent": "Forge / deterministic demo",
            "model": None,
            "prompt_hash": None,
            "source_hashes": [before_hash],
            "approval_state": "EXPLICIT_L2_APPROVAL",
        }
        artifact_record = self.ledgers["artifacts"].append("artifact_created", artifact)
        lineage_path = self._write_json(
            "evidence/11_lineage_and_repair.json",
            {"artifact": artifact_record, "incident": incident_record},
        )
        self._gate(GATES[10], "Lineage and the rejected-action repair chain were retained.", [self._rel(lineage_path)])

        restore_probe = self.evidence_dir / "restore_probe.json"
        shutil.copy2(settings, restore_probe)
        shutil.copy2(snapshot, restore_probe)
        reversible = sha256_file(restore_probe) == before_hash
        disposition = {
            "decision": "ACCEPT",
            "reason": "Verification passed and rollback was proven byte-for-byte.",
            "rollback_test_passed": reversible,
            "accepted_sha256": sha256_file(settings),
        }
        disposition_path = self._write_json("evidence/12_disposition.json", disposition)
        self.ledgers["decisions"].append("cycle_accepted", disposition)
        self._gate(GATES[11], "Change accepted after verification and rollback proof.", [self._rel(disposition_path)])

        matrix = [
            {"claim": name, "mechanism": mechanism, "test": test, "status": status.value}
            for name, mechanism, test, status in CLAIM_MATRIX
        ]
        for row in matrix:
            self.ledgers["constitution"].append("principle_status", row)

        ledger_checks = {}
        for name, ledger in self.ledgers.items():
            ok, message = ledger.verify()
            ledger_checks[name] = {"passed": ok, "message": message}

        summary = {
            "system": "VOID OS Φ∞ v7.4 — The Evidence Covenant",
            "status": "PROMISING EARLY ALPHA",
            "cycle_id": self.run_id,
            "result": "ACCEPTED",
            "elapsed_seconds": round(time.perf_counter() - started, 4),
            "network_used": False,
            "ollama_required": False,
            "generated_code_executed": False,
            "gates": self.gates,
            "claim_matrix": matrix,
            "verification": verification,
            "authority": authority,
            "consent": decision_dict(approval),
            "lineage": artifact,
            "incident": incident,
            "ledger_checks": ledger_checks,
            "honest_limitations": [
                "This is a governance-path demo, not proof of safe unattended code execution.",
                "The execution chamber remains disabled and unverified.",
                "The demo verifies its deterministic fixture, not every existing VOID OS subsystem.",
            ],
        }
        summary_path = self._write_json("cycle_summary.json", summary)
        report_path = self.run_dir / "EVIDENCE_REPORT.html"
        report_path.write_text(render_report(summary), encoding="utf-8")
        summary["summary_path"] = str(summary_path)
        summary["report_path"] = str(report_path)
        return summary


def render_report(summary: dict[str, Any]) -> str:
    def esc(value: Any) -> str:
        return html.escape(str(value))

    gates = "".join(
        f"""<article class="gate"><span>{gate['number']:02d}</span><div><b>{esc(gate['name'])}</b>
        <p>{esc(gate['outcome'])}</p></div><em>VERIFIED</em></article>"""
        for gate in summary["gates"]
    )
    matrix = "".join(
        f"<tr><td>{esc(row['claim'])}</td><td>{esc(row['mechanism'])}</td>"
        f"<td>{esc(row['test'])}</td><td><strong class='{row['status'].lower()}'>{esc(row['status'])}</strong></td></tr>"
        for row in summary["claim_matrix"]
    )
    ledgers = "".join(
        f"<li><b>{esc(name.title())}</b><span>{esc(check['message'])}</span></li>"
        for name, check in summary["ledger_checks"].items()
    )
    limits = "".join(f"<li>{esc(item)}</li>" for item in summary["honest_limitations"])
    return f"""<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width">
<title>VOID OS v7.4 Evidence Report</title>
<style>
:root{{--ink:#eef5f1;--muted:#91a7a0;--void:#080b0d;--panel:#10171a;--line:#233038;--gold:#e6b95d;--teal:#49d8bd;--rose:#df577b;}}
*{{box-sizing:border-box}} body{{margin:0;background:radial-gradient(circle at 70% 0,#17252a 0,var(--void) 42%);
color:var(--ink);font:15px/1.55 ui-monospace,SFMono-Regular,Consolas,monospace}} main{{max-width:1180px;margin:auto;padding:40px 24px 80px}}
.eyebrow{{color:var(--gold);letter-spacing:.2em}} h1{{font:700 clamp(30px,5vw,64px)/1.02 Georgia,serif;margin:.25em 0}}
.subtitle{{color:var(--muted);max-width:780px;font-size:17px}} .status{{display:flex;gap:10px;flex-wrap:wrap;margin:24px 0 38px}}
.pill{{border:1px solid var(--line);border-radius:999px;padding:7px 12px;background:#0d1316}} .ok{{color:var(--teal)}}
.grid{{display:grid;grid-template-columns:1fr 1fr;gap:18px}} section{{border:1px solid var(--line);background:linear-gradient(145deg,#11191c,#0b1012);
padding:22px;border-radius:14px;margin-bottom:18px}} h2{{font:600 24px Georgia,serif;margin:0 0 16px;color:var(--gold)}}
.gate{{display:grid;grid-template-columns:42px 1fr auto;gap:12px;border-top:1px solid var(--line);padding:13px 0;align-items:center}}
.gate:first-of-type{{border-top:0}} .gate>span{{color:var(--gold)}} .gate p{{margin:3px 0;color:var(--muted)}} .gate em{{color:var(--teal);font-style:normal;font-size:11px}}
table{{width:100%;border-collapse:collapse}} td,th{{border-top:1px solid var(--line);padding:11px;text-align:left;vertical-align:top}} th{{color:var(--muted)}}
.verified{{color:var(--teal)}} .enforced{{color:var(--gold)}} .metric{{font:700 42px Georgia,serif;color:var(--teal)}} ul{{padding-left:20px}}
.ledger{{list-style:none;padding:0}} .ledger li{{display:flex;justify-content:space-between;gap:20px;border-top:1px solid var(--line);padding:10px 0}}
.ledger span{{color:var(--teal)}} footer{{color:var(--muted);margin-top:35px}}
@media(max-width:800px){{.grid{{grid-template-columns:1fr}}.gate{{grid-template-columns:32px 1fr}}.gate em{{display:none}}}}
</style></head><body><main>
<div class="eyebrow">VOID OS Φ∞ // EVIDENCE COVENANT</div><h1>Make the machinery<br>deserve the myth.</h1>
<p class="subtitle">A deterministic local demonstration of rights, evidence, lineage, consent, reversibility, and visible repair.</p>
<div class="status"><span class="pill ok">● {esc(summary['result'])}</span><span class="pill">Cycle {esc(summary['cycle_id'])}</span>
<span class="pill">No Ollama required</span><span class="pill">No network used</span><span class="pill">Generated execution disabled</span></div>
<div class="grid"><section><h2>Measured result</h2><div class="metric">1 → 0</div><p>Duplicate configuration entries, measured before and after.</p>
<p>Claim: <b>{esc(summary['verification']['classification'])}</b></p></section>
<section><h2>Authority result</h2><p>L5 external action: <b class="ok">DENIED</b></p><p>L4 generated-code execution: <b class="ok">DENIED</b></p>
<p>L2 sandbox modification: <b class="ok">EXPLICITLY APPROVED</b></p></section></div>
<section><h2>Twelve-gate cycle</h2>{gates}</section>
<section><h2>Claim-to-mechanism matrix</h2><table><thead><tr><th>Claim</th><th>Mechanism</th><th>Test</th><th>Status</th></tr></thead>
<tbody>{matrix}</tbody></table></section>
<div class="grid"><section><h2>Ledger integrity</h2><ul class="ledger">{ledgers}</ul></section>
<section><h2>Visible repair</h2><p><b>Failure:</b> {esc(summary['incident']['failed_attempt'])}</p>
<p><b>Diagnosis:</b> {esc(summary['incident']['diagnosis'])}</p><p><b>Repair:</b> {esc(summary['incident']['repair'])}</p>
<p><b>Retest:</b> {esc(summary['incident']['retest'])}</p></section></div>
<section><h2>Honest limitations</h2><ul>{limits}</ul></section>
<footer>VOID OS Φ∞ v7.4 · State: PROMISING EARLY ALPHA · Operator: @LastingCzardd / @reson8labs</footer>
</main></body></html>"""
