# v7.4 — Evidence Covenant

## Added

- Executable L0–L5 authority model with an autonomous allowance and hard ceiling.
- Explicit consent decisions where silence cannot authorize an L2 change.
- Five append-only, SHA-256-chained institutional ledgers.
- Claim classifications: OBSERVED, INFERRED, PROPOSED, UNVERIFIED,
  CONTRADICTED, and VERIFIED.
- A deterministic twelve-gate governance cycle runnable without Ollama.
- Three materially different solution options with consequences and jurisdiction.
- Pre-change snapshots and byte-for-byte rollback testing.
- Artifact lineage with source hashes, parent IDs, cycle ID, creator, model,
  prompt hash, and approval state.
- A visible failure → diagnosis → repair → retest incident record.
- A machine-readable claim-to-mechanism matrix.
- An offline HTML evidence dashboard produced after each run.
- Unit tests for consent denial, ceiling enforcement, ledger tamper detection,
  complete gate coverage, evidence output, and retained v7.3.1 cycle behavior.
- One-click Windows launchers and a complete verification command.

## Preserved

- Existing local Ollama routing, agent set, Tkinter interface, datasets, project
  cycle machinery, coding studio, plugin manager, research engine, and tester
  cycle budgets.

## Deliberately not claimed

- Production-safe unattended generated-code execution.
- A verified operating-system-grade sandbox.
- Verification of arbitrary model output quality.
- Verification of every legacy subsystem through the deterministic fixture.
