"""Canonical release gate for VOID OS v8.4.

Runs only local, deterministic checks. It does not install dependencies, contact
Ollama, execute generated code, or modify active project state.
"""
from __future__ import annotations

import json
import subprocess
import sys
import tempfile
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

ROOT = Path(__file__).resolve().parent
RELEASE_NAME = "VOID_OS_Local_v8_4_Mathematical_Substrate"
RELEASE_ZIP = ROOT.parent / f"{RELEASE_NAME}.zip"

REQUIRED_FILES = (
    "README.md",
    "NOTICE.txt",
    "BUILD_INFO.json",
    "config.json",
    "START_EVIDENCE_DEMO.bat",
    "START_VOID_OS.bat",
    "START_MATH_KERNEL.bat",
    "START_MATH_DASHBOARD.bat",
    "VERIFY_MATH_KERNEL.bat",
    "VERIFY_DEMO.py",
    "VERIFY_SECURITY.py",
    "CORE_MANIFEST_SHA256.json",
    "MANIFEST_SHA256.json",
)

EXCLUDED_PARTS = {
    ".git",
    ".pytest_cache",
    ".mypy_cache",
    ".ruff_cache",
    "__pycache__",
    ".venv",
    "venv",
    "demo_runs",
}
EXCLUDED_SUFFIXES = {".pyc", ".pyo", ".zip"}
EXCLUDED_PREFIXES = {("data", "secrets"), ("data", "logs"), ("data", "runtime")}


def run(label: str, command: list[str]) -> None:
    print(f"\n== {label} ==")
    completed = subprocess.run(command, cwd=ROOT, check=False)
    if completed.returncode:
        raise SystemExit(completed.returncode)


def verify_required_files() -> None:
    missing = [name for name in REQUIRED_FILES if not (ROOT / name).is_file()]
    if missing:
        raise RuntimeError("Missing release files: " + ", ".join(missing))


def verify_json_files() -> None:
    for path in sorted(ROOT.rglob("*.json")):
        if any(part in EXCLUDED_PARTS for part in path.parts):
            continue
        try:
            json.loads(path.read_text(encoding="utf-8"))
        except Exception as exc:
            raise RuntimeError(f"Invalid JSON: {path.relative_to(ROOT)}: {exc}") from exc


def package_files() -> list[Path]:
    files: list[Path] = []
    for path in ROOT.rglob("*"):
        if not path.is_file():
            continue
        relative = path.relative_to(ROOT)
        if any(part in EXCLUDED_PARTS for part in relative.parts):
            continue
        if any(relative.parts[:len(prefix)] == prefix for prefix in EXCLUDED_PREFIXES):
            continue
        if path.suffix.lower() in EXCLUDED_SUFFIXES:
            continue
        files.append(path)
    return sorted(files, key=lambda item: item.as_posix().lower())


def build_release_archive() -> None:
    files = package_files()
    if not files:
        raise RuntimeError("Release package would be empty.")
    if RELEASE_ZIP.exists():
        RELEASE_ZIP.unlink()
    forbidden = [p for p in files if "secrets" in p.relative_to(ROOT).parts]
    if forbidden:
        raise RuntimeError("Secret-bearing paths entered the package set.")
    with ZipFile(RELEASE_ZIP, "w", compression=ZIP_DEFLATED, compresslevel=9) as archive:
        for path in files:
            relative = path.relative_to(ROOT)
            archive.write(path, arcname=f"{RELEASE_NAME}/{relative.as_posix()}")
    print(f"Created: {RELEASE_ZIP}")
    print(f"Packaged files: {len(files)}")


def main() -> int:
    print("VOID OS v8.4 canonical release gate")
    verify_required_files()
    verify_json_files()
    run("Compile", [sys.executable, "-m", "compileall", "-q", "void_os", "tests"])
    run("Unit tests", [sys.executable, "-m", "unittest", "discover", "-s", "tests", "-v"])
    with tempfile.TemporaryDirectory(prefix="void-os-release-check-") as temporary:
        run(
            "Deterministic offline evidence cycle",
            [sys.executable, "run_evidence_demo.py", "--no-open", "--output", temporary],
        )
    run("Security and manifest verification", [sys.executable, "VERIFY_SECURITY.py"])
    build_release_archive()
    print("\nRELEASE GATE PASSED")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
