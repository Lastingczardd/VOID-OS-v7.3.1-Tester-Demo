import json
import tempfile
import unittest
from pathlib import Path

from void_os.core.events import EventBus, EventRejected
from void_os.core.runtime import EngineeringRuntime
from void_os.autopilot.predictive_value import PredictiveValueModel


class EngineeringOSV8Tests(unittest.TestCase):
    def test_event_bus_persists_and_replays(self):
        with tempfile.TemporaryDirectory() as td:
            bus = EventBus(Path(td))
            seen = []
            bus.subscribe("OpportunityDiscovered", lambda event: seen.append(event.payload["task"]))
            bus.emit("OpportunityDiscovered", {"task": "reduce startup time"}, cycle=2)
            self.assertEqual(seen, ["reduce startup time"])
            replayed = bus.replay("OpportunityDiscovered")
            self.assertEqual(len(replayed), 1)
            self.assertEqual(replayed[0].cycle, 2)

    def test_runtime_builds_knowledge_and_portfolio_projections(self):
        with tempfile.TemporaryDirectory() as td:
            runtime = EngineeringRuntime(Path(td))
            runtime.bus.emit("EngineeringClaimed", {"problem": "startup is slow", "fingerprint": "abc"}, cycle=1)
            runtime.request_governor_decision({
                "decision": "ACCEPT", "accepted": True, "vis": 0.5, "fingerprint": "abc",
                "predictive": {"expected_long_term_value": 1.2, "regression_probability": 0.1, "maintenance_pressure": 0.2},
            }, cycle=1, state_changes={"active_project": "generation-1"})
            self.assertTrue((Path(td) / "engineering_knowledge_graph.jsonl").exists())
            portfolio = [json.loads(x) for x in (Path(td) / "engineering_portfolio.jsonl").read_text().splitlines()]
            self.assertEqual(portfolio[0]["decision"], "ACCEPT")
            state = runtime.state.load()
            self.assertEqual(state["active_project"], "generation-1")
            self.assertEqual(len(state["constitutional_receipt"]), 64)

    def test_governor_decision_cannot_bypass_constitutional_gateway(self):
        with tempfile.TemporaryDirectory() as td:
            runtime = EngineeringRuntime(Path(td))
            with self.assertRaises(EventRejected):
                runtime.bus.emit(
                    "GovernorDecision",
                    {"decision": "ACCEPT"},
                    source="builder_orchestra",
                    cycle=1,
                )

    def test_predictive_value_cannot_rescue_rejected_change(self):
        model = PredictiveValueModel({"predictive_value": {}})
        forecast = model.forecast({
            "accepted": False, "complexity": {"cost": 1}, "risk": 0,
            "confidence": 1, "durability": 1, "outcome_gain": 100,
        })
        self.assertEqual(forecast["expected_long_term_value"], 0.0)


if __name__ == "__main__":
    unittest.main()
