import tempfile
import unittest
from pathlib import Path
from void_os.autopilot.value_integrity import EngineeringClaim, ValueIntegrityEngine

class ValueIntegrityTests(unittest.TestCase):
    def test_added_tests_do_not_create_outcome_value(self):
        ok={"passed":True,"status":"NOT_CONFIGURED"}
        before={"source_lines":10,"test_lines":0}
        after={"source_lines":10,"test_lines":500}
        self.assertEqual(ValueIntegrityEngine._outcome_gain(before,after,ok,ok,ok,ok,True),1.0)

    def test_test_padding_is_flagged(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td); state=root/'state'; code=root/'code'; code.mkdir()
            engine=ValueIntegrityEngine({},code,state)
            before={"files":[],"bytes":100,"source_lines":100,"test_lines":10,"dependency_imports":0}
            after={"files":[],"bytes":10000,"source_lines":105,"test_lines":400,"dependency_imports":0}
            result=engine._complexity_delta(before,after)
            self.assertTrue(result["test_padding_suspected"])
            self.assertGreaterEqual(result["cost"],12)

    def test_claim_fingerprint_is_stable(self):
        claim=EngineeringClaim("Fix startup crash","Guard missing config","No crash","Local users","Regression test")
        self.assertEqual(ValueIntegrityEngine._fingerprint(claim),ValueIntegrityEngine._fingerprint(claim))

if __name__ == '__main__': unittest.main()
