import tempfile
import unittest
from pathlib import Path

from void_os.core.events import EventBus
from void_os.core.runtime import EngineeringRuntime
from void_os.governance.constitutional_gate import BuilderGoal, GoalDisposition
from void_os.orchestra.builder import BuilderOrchestra


class FakeAgents:
    def __init__(self):
        self.agents = {
            name: object()
            for name in ("Architect", "Coder", "Test Engineer", "Critic")
        }

    def team_run(self, prompt, names):
        return {"synthesis": f"evidence from {names[0]}"}


class ConstitutionalOrchestraIntegrationTests(unittest.TestCase):
    def test_orchestra_emits_evidence_but_cannot_advance_state(self):
        with tempfile.TemporaryDirectory() as tmp:
            runtime = EngineeringRuntime(Path(tmp), FakeAgents())
            plan = runtime.orchestra.plan(
                {
                    "task": "Make one bounded reversible repair.",
                    "team": ["Architect", "Coder", "Test Engineer", "Critic"],
                    "winner": {"verification": "Measure the repaired outcome."},
                },
                1,
            )
            report = runtime.orchestra.run(plan, "verified local failure")
            self.assertEqual(report["status"], "COMPLETE")
            self.assertEqual(runtime.bus.replay("GovernorDecision"), [])
            self.assertEqual(runtime.state.load(), {})

    def test_unresolved_builder_goal_blocks_governor_then_resolution_allows(self):
        with tempfile.TemporaryDirectory() as tmp:
            runtime = EngineeringRuntime(Path(tmp))
            runtime.governance.goals.declare(
                BuilderGoal("GOAL-V8", "@LastingCzardd", "Preserve builder authority.")
            )
            runtime.request_governor_decision(
                {"decision": "ACCEPT", "accepted": True, "fingerprint": "first"},
                cycle=1,
                builder_goal_id="GOAL-V8",
                state_changes={"active_project": "blocked-generation"},
            )
            self.assertEqual(runtime.bus.replay("GovernorDecision"), [])
            self.assertEqual(len(runtime.bus.replay("MutationBlocked")), 1)
            runtime.governance.goals.resolve(
                "GOAL-V8",
                GoalDisposition.SCHEDULED,
                constitutional_reason="Scheduled in the bounded v8 cycle.",
            )
            runtime.request_governor_decision(
                {"decision": "ACCEPT", "accepted": True, "fingerprint": "second"},
                cycle=2,
                builder_goal_id="GOAL-V8",
                state_changes={"active_project": "accepted-generation"},
            )
            decisions = runtime.bus.replay("GovernorDecision")
            self.assertEqual(len(decisions), 1)
            self.assertEqual(runtime.state.load()["active_project"], "accepted-generation")


if __name__ == "__main__":
    unittest.main()
