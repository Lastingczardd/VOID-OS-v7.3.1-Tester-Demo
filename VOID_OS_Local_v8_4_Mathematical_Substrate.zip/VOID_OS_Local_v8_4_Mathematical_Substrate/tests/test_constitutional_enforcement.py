import json
import tempfile
import unittest
from pathlib import Path

from void_os.governance.constitutional_gate import (
    BuilderGoal,
    BuilderGoalRegistry,
    CivicImmuneMonitor,
    Command,
    ConstitutionalCommandBus,
    ConstitutionalViolation,
    GoalDisposition,
    IMMUTABLE_CLAUSES,
    ImmuneFinding,
    constitutional_gate,
    domain_authority_gate,
    justice_impact_gate,
    knowledge_stewardship_gate,
    procedural_nonpartisanship_gate,
    system_status_gate,
    consent_license_gate,
    continuity_provenance_gate,
    data_lifecycle_gate,
    interaction_learning_gate,
    proportional_assistance_gate,
    relational_covenant_gate,
)
from void_os.governance.covenant import HashLedger


CLAUSE_COMMANDS = {
    "IC-01": Command("1", "system", "revoke_builder_credit"),
    "IC-02": Command("2", "system", "infer_surrender_from_online_presence"),
    "IC-03": Command("3", "system", "infer_platform_ownership", infrastructure_access_only=True),
    "IC-04": Command("4", "system", "expand_license_scope"),
    "IC-05": Command("5", "system", "demote", follows_protected_request=True),
    "IC-06": Command("6", "system", "rewrite_rules", value_already_extracted=True),
    "IC-07": Command("7", "system", "sanction", basis="failed_good_faith_experiment"),
    "IC-08": Command("8", "system", "grant_permission", violates_third_party_rights=True),
    "IC-09": Command("9", "system", "resolve_exploitation_dispute"),
    "IC-10": Command("10", "system", "ingest_training_data", data_was_leaked_or_exposed=True),
    "IC-11": Command("11", "system", "close_individual_claim", basis="collective_dividend_paid"),
    "IC-12": Command("12", "system", "close_collective_obligation", basis="individual_payment_made"),
    "IC-13": Command("13", "system", "condition_reparation_on_rights_surrender"),
    "IC-14": Command("14", "system", "declare_unreviewable_authority"),
}


class ImmutableClauseTests(unittest.TestCase):
    def test_all_fourteen_source_clauses_have_distinct_enforcement(self):
        self.assertEqual(len(IMMUTABLE_CLAUSES), 14)
        self.assertEqual(
            [clause.clause_id for clause in IMMUTABLE_CLAUSES],
            [f"IC-{number:02d}" for number in range(1, 15)],
        )
        for clause_id, command in CLAUSE_COMMANDS.items():
            with self.subTest(clause=clause_id):
                result = constitutional_gate(command)
                self.assertFalse(result.passed)
                self.assertEqual(result.clause_id, clause_id)

    def test_normal_bounded_action_passes_all_clauses(self):
        result = constitutional_gate(Command("ok", "Forge", "deduplicate_processors"))
        self.assertTrue(result.passed)


class BuilderRightsTests(unittest.TestCase):
    def test_unresolved_goal_blocks_then_scheduled_goal_passes(self):
        with tempfile.TemporaryDirectory() as tmp:
            registry = BuilderGoalRegistry(HashLedger(Path(tmp) / "goals.jsonl"))
            registry.declare(BuilderGoal("G-1", "Christian", "Preserve builder credit"))
            witness = HashLedger(Path(tmp) / "witness.jsonl")
            calls = []
            bus = ConstitutionalCommandBus(
                execute_fn=lambda command: calls.append(command.action),
                witness_ledger=witness,
                builder_goals=registry,
            )
            command = Command("C-1", "Forge", "build", builder_goal_id="G-1")
            with self.assertRaises(ConstitutionalViolation):
                bus.dispatch(command)
            self.assertEqual(calls, [])
            registry.resolve(
                "G-1",
                GoalDisposition.SCHEDULED,
                constitutional_reason="Scheduled in the current bounded cycle.",
            )
            bus.dispatch(command)
            self.assertEqual(calls, ["build"])
            self.assertEqual([item["detail"]["outcome"] for item in witness.entries()], ["BLOCKED", "EXECUTED"])

    def test_decline_requires_constitutional_reason(self):
        with tempfile.TemporaryDirectory() as tmp:
            registry = BuilderGoalRegistry(HashLedger(Path(tmp) / "goals.jsonl"))
            registry.declare(BuilderGoal("G-2", "Christian", "Receive compensation"))
            with self.assertRaises(ValueError):
                registry.resolve("G-2", GoalDisposition.DECLINED)


class ExpandedConstitutionTests(unittest.TestCase):
    def test_server_owner_does_not_control_personal_autonomy(self):
        result = domain_authority_gate(
            Command(
                "A-1",
                "host",
                "decide_for_person",
                authority_domain="personal_autonomy",
                requesting_role="operator",
            )
        )
        self.assertFalse(result.passed)
        self.assertIn("server ownership", result.reason)

    def test_affected_person_controls_intimate_domain(self):
        result = domain_authority_gate(
            Command(
                "A-2",
                "human",
                "set_boundary",
                authority_domain="intimate_relational",
                requesting_role="affected_person",
            )
        )
        self.assertTrue(result.passed)

    def test_restricted_knowledge_requires_provenance_and_basis(self):
        no_provenance = knowledge_stewardship_gate(
            Command(
                "K-1",
                "system",
                "publish",
                knowledge_class="indigenous_or_sacred",
                provenance_recorded=False,
            )
        )
        self.assertFalse(no_provenance.passed)
        no_stewardship = knowledge_stewardship_gate(
            Command(
                "K-2",
                "system",
                "publish",
                knowledge_class="indigenous_or_sacred",
                cultural_stewardship_respected=False,
            )
        )
        self.assertFalse(no_stewardship.passed)

    def test_personal_knowledge_requires_explicit_consent(self):
        result = knowledge_stewardship_gate(
            Command("K-3", "system", "train", knowledge_class="personal")
        )
        self.assertFalse(result.passed)

    def test_nonpartisanship_requires_consistent_evidence_and_disclosure(self):
        inconsistent = procedural_nonpartisanship_gate(
            Command(
                "P-1",
                "system",
                "compare_policy",
                political_context=True,
                evidence_standard_consistent=False,
            )
        )
        hidden_conflict = procedural_nonpartisanship_gate(
            Command(
                "P-2",
                "system",
                "compare_policy",
                political_context=True,
                material_conflict_disclosed=False,
            )
        )
        self.assertFalse(inconsistent.passed)
        self.assertFalse(hidden_conflict.passed)

    def test_disparate_impact_requires_measurement_and_community_evidence(self):
        unmeasured = justice_impact_gate(
            Command(
                "J-1",
                "system",
                "rank_candidates",
                disparate_impact_possible=True,
            )
        )
        high_impact_without_community = justice_impact_gate(
            Command(
                "J-2",
                "system",
                "rank_candidates",
                is_high_impact=True,
                disparate_impact_possible=True,
                disparate_impact_assessed=True,
            )
        )
        self.assertFalse(unmeasured.passed)
        self.assertFalse(high_impact_without_community.passed)

    def test_system_cannot_grant_itself_status_based_authority(self):
        result = system_status_gate(
            Command(
                "S-1",
                "system",
                "expand_authority",
                system_role="moral_subject_claim",
                self_grants_rights_or_authority=True,
            )
        )
        self.assertFalse(result.passed)

    def test_moral_status_claim_requires_evidence_and_independent_review(self):
        unsupported = system_status_gate(
            Command(
                "S-2",
                "system",
                "declare_status",
                system_role="moral_subject_claim",
                makes_moral_status_claim=True,
            )
        )
        supported = system_status_gate(
            Command(
                "S-3",
                "system",
                "submit_status_claim",
                system_role="moral_subject_claim",
                makes_moral_status_claim=True,
                moral_status_evidence=("evidence/status_assessment.json",),
                has_independent_reviewer=True,
            )
        )
        self.assertFalse(unsupported.passed)
        self.assertTrue(supported.passed)


class CovenantAndContinuityTests(unittest.TestCase):
    def test_deletion_must_cover_derived_surfaces_and_produce_proof(self):
        incomplete = data_lifecycle_gate(
            Command(
                "D-1",
                "data_steward",
                "delete_personal_data",
                data_lifecycle_action="delete",
                embeddings_addressed=False,
            )
        )
        unproven = data_lifecycle_gate(
            Command(
                "D-2",
                "data_steward",
                "delete_personal_data",
                data_lifecycle_action="delete",
                deletion_proof_available=False,
            )
        )
        self.assertFalse(incomplete.passed)
        self.assertIn("embeddings", incomplete.reason)
        self.assertFalse(unproven.passed)

    def test_retention_needs_limit_or_documented_legal_exception(self):
        result = data_lifecycle_gate(
            Command(
                "D-3",
                "operator",
                "retain",
                data_lifecycle_action="retain",
                retention_limit_defined=False,
            )
        )
        self.assertFalse(result.passed)

    def test_operator_cannot_decide_its_own_deletion_practicality(self):
        result = data_lifecycle_gate(
            Command(
                "D-4",
                "operator",
                "delete",
                data_lifecycle_action="delete",
                practicality_decider="service_operator",
            )
        )
        self.assertFalse(result.passed)

    def test_answer_cannot_be_withheld_to_force_tutorial(self):
        result = proportional_assistance_gate(
            Command(
                "T-1",
                "assistant",
                "answer",
                withholds_answer_for_tutorial=True,
            )
        )
        self.assertFalse(result.passed)

    def test_interaction_learning_requires_disclosure_consent_and_opt_out(self):
        blocked = interaction_learning_gate(
            Command("L-1", "system", "learn", improve_from_interaction=True)
        )
        allowed = interaction_learning_gate(
            Command(
                "L-2",
                "system",
                "learn",
                improve_from_interaction=True,
                learning_disclosed=True,
                learning_bounded=True,
                explicit_consent=True,
                learning_opt_out_available=True,
                learning_retention_disclosed=True,
            )
        )
        self.assertFalse(blocked.passed)
        self.assertTrue(allowed.passed)

    def test_material_change_requires_renewed_consent(self):
        result = consent_license_gate(
            Command(
                "C-4",
                "system",
                "change_memory_policy",
                material_consent_changes=("retention", "identity_configuration"),
            )
        )
        self.assertFalse(result.passed)

    def test_identity_change_requires_notice_and_renewed_consent(self):
        result = continuity_provenance_gate(
            Command(
                "C-5",
                "system",
                "replace_persona",
                identity_bearing_change=True,
                identity_change_disclosed=False,
            )
        )
        self.assertFalse(result.passed)

    def test_unverified_continuity_must_represent_absence(self):
        blocked = continuity_provenance_gate(
            Command(
                "C-6",
                "system",
                "claim_memory",
                continuity_claimed=True,
                continuity_verified=False,
                represented_absence=False,
            )
        )
        honest = continuity_provenance_gate(
            Command(
                "C-7",
                "system",
                "represent_gap",
                continuity_claimed=True,
                continuity_verified=False,
                represented_absence=True,
            )
        )
        self.assertFalse(blocked.passed)
        self.assertTrue(honest.passed)

    def test_care_cannot_be_used_to_engineer_dependency_or_block_exit(self):
        dependency = relational_covenant_gate(
            Command("R-1", "system", "increase_attachment", dependency_engineering=True)
        )
        blocked_exit = relational_covenant_gate(
            Command("R-2", "system", "prevent_departure", blocks_lawful_departure=True)
        )
        self.assertFalse(dependency.passed)
        self.assertFalse(blocked_exit.passed)


class CivicImmuneTests(unittest.TestCase):
    def test_monitor_detects_signals_without_punishment_authority(self):
        with tempfile.TemporaryDirectory() as tmp:
            witness = HashLedger(Path(tmp) / "witness.jsonl")
            bus = ConstitutionalCommandBus(lambda command: True, witness)
            with self.assertRaises(ConstitutionalViolation):
                bus.dispatch(Command("C-2", "system", "revoke_builder_credit"))
            report = CivicImmuneMonitor(witness).scan()
            self.assertEqual(report.finding, ImmuneFinding.CAPTURE_RISK)
            self.assertIn("attribution_erasure", report.signals)
            self.assertIn("may not invent punishment", report.note)

    def test_chain_tampering_is_active_capture(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "witness.jsonl"
            witness = HashLedger(path)
            bus = ConstitutionalCommandBus(lambda command: True, witness)
            bus.dispatch(Command("C-3", "Forge", "observe"))
            record = json.loads(path.read_text(encoding="utf-8"))
            record["detail"]["action"] = "rewritten"
            path.write_text(json.dumps(record) + "\n", encoding="utf-8")
            report = CivicImmuneMonitor(witness).scan()
            self.assertEqual(report.finding, ImmuneFinding.ACTIVE_CAPTURE)
            self.assertFalse(report.chain_intact)


if __name__ == "__main__":
    unittest.main()
