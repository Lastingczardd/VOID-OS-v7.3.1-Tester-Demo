import tempfile
import unittest
from pathlib import Path

from void_os.core.events import EventBus
from void_os.orchestra.builder import BuilderOrchestra


class FakeAgents:
    def __init__(self):
        self.agents = {name: object() for name in ["Architect", "Coder", "Test Engineer", "Critic"]}
        self.calls = []

    def team_run(self, prompt, names):
        self.calls.append((names[0], prompt))
        return {"synthesis": f"verified contribution from {names[0]}"}


class BuilderOrchestraTests(unittest.TestCase):
    def test_plan_uses_only_available_agents_and_emits_events(self):
        with tempfile.TemporaryDirectory() as td:
            bus = EventBus(Path(td))
            agents = FakeAgents()
            orchestra = BuilderOrchestra(agents, bus)
            packet = {
                "task": "Reduce startup time without increasing complexity.",
                "team": ["Architect", "Researcher", "Coder", "Test Engineer", "Critic"],
                "winner": {"verification": "Compare cold-start median to baseline."},
            }
            plan = orchestra.plan(packet, 3)
            self.assertNotIn("Researcher", plan.execution_order)
            self.assertEqual(plan.execution_order[0], "Architect")
            self.assertEqual(len(bus.replay("OrchestraPlanned")), 1)

    def test_run_keeps_promotion_authority_outside_builder(self):
        with tempfile.TemporaryDirectory() as td:
            bus = EventBus(Path(td))
            agents = FakeAgents()
            orchestra = BuilderOrchestra(agents, bus)
            plan = orchestra.plan({
                "task": "Fix bounded failure",
                "team": ["Architect", "Coder", "Test Engineer", "Critic"],
                "winner": {},
            }, 1)
            report = orchestra.run(plan, "traceback evidence")
            self.assertEqual(report["status"], "COMPLETE")
            self.assertIn("VIE and the Governor", report["synthesis"])
            self.assertEqual(len(bus.replay("SpecialistFinished")), 4)
            self.assertFalse(any("GovernorDecision" == e.name for e in bus.replay()))


if __name__ == "__main__":
    unittest.main()
