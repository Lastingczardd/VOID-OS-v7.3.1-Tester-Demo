import tempfile
import unittest
from pathlib import Path

from void_os.math_kernel import NullKernel, TransitionRequest
from void_os.math_kernel.math_substrate import (
    digital_root,
    reduce_text,
    tetractys,
    triangle_reduced,
    verify_fold_invariant,
)


class MathematicalSubstrateTests(unittest.TestCase):
    def test_digital_root_and_symbol_reduction(self):
        self.assertEqual(digital_root(0), 0)
        self.assertEqual(digital_root(666), 9)
        self.assertEqual(reduce_text("VOID"), (23, 5))
        self.assertEqual(reduce_text("NULL"), (14, 5))

    def test_triangle_and_tetractys(self):
        self.assertEqual(tetractys(4), 10)
        self.assertEqual(triangle_reduced(4), 1)

    def test_deepen_fold_invariant(self):
        for value in (-2, -1, 0, 0.5, 1, 2):
            report = verify_fold_invariant(value, 2, tolerance=1e-7)
            self.assertTrue(report.passed, report)

    def test_normalize_preserves_hash_chained_history(self):
        with tempfile.TemporaryDirectory() as temp:
            kernel = NullKernel(Path(temp) / "math-kernel.db")
            kernel.boot()
            accepted, _ = kernel.apply(TransitionRequest("polarize", 1))
            normalized, state = kernel.apply(TransitionRequest("normalize"))
            self.assertTrue(accepted.allowed)
            self.assertTrue(normalized.allowed)
            self.assertEqual(state.z, 0.0)
            self.assertGreaterEqual(len(kernel.ledger.recent(20)), 3)
            valid, errors = kernel.ledger.verify()
            self.assertTrue(valid, errors)

    def test_reality_veto_blocks_unknown_and_empty_observation(self):
        with tempfile.TemporaryDirectory() as temp:
            kernel = NullKernel(Path(temp) / "math-kernel.db")
            unknown, _ = kernel.apply(TransitionRequest("unknown"))
            empty, _ = kernel.apply(TransitionRequest("observe", reason=""))
            self.assertFalse(unknown.allowed)
            self.assertFalse(empty.allowed)


if __name__ == "__main__":
    unittest.main()
