import json
import tempfile
import unittest
from pathlib import Path

from void_os.governance.covenant import AuthorityLevel, ConsentEngine, HashLedger
from void_os.governance.demo_cycle import EvidenceCovenantDemo, GATES


class ConsentTests(unittest.TestCase):
    def setUp(self):
        self.engine = ConsentEngine(
            autonomous_through=AuthorityLevel.PROPOSE,
            maximum_level=AuthorityLevel.MODIFY_SANDBOX,
        )

    def test_silence_is_not_consent(self):
        decision = self.engine.decide("modify", AuthorityLevel.MODIFY_SANDBOX)
        self.assertFalse(decision.allowed)
        self.assertIn("silence", decision.reason)

    def test_explicit_approval_cannot_cross_ceiling(self):
        decision = self.engine.decide(
            "external", AuthorityLevel.AFFECT_EXTERNAL_SYSTEMS, explicit_approval=True
        )
        self.assertFalse(decision.allowed)

    def test_explicit_approval_allows_bounded_action(self):
        decision = self.engine.decide(
            "sandbox", AuthorityLevel.MODIFY_SANDBOX, explicit_approval=True
        )
        self.assertTrue(decision.allowed)


class LedgerTests(unittest.TestCase):
    def test_tampering_is_detected(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "ledger.jsonl"
            ledger = HashLedger(path)
            ledger.append("observed", {"value": 1})
            ledger.append("verified", {"value": 2})
            self.assertTrue(ledger.verify()[0])
            lines = path.read_text(encoding="utf-8").splitlines()
            changed = json.loads(lines[0])
            changed["detail"]["value"] = 999
            lines[0] = json.dumps(changed)
            path.write_text("\n".join(lines) + "\n", encoding="utf-8")
            self.assertFalse(ledger.verify()[0])


class FullCycleTests(unittest.TestCase):
    def test_cycle_exercises_all_gates_and_retains_limits(self):
        with tempfile.TemporaryDirectory() as tmp:
            result = EvidenceCovenantDemo(Path(tmp)).run()
            self.assertEqual([item["name"] for item in result["gates"]], GATES)
            self.assertEqual(result["result"], "ACCEPTED")
            self.assertTrue(result["verification"]["passed"])
            self.assertEqual(result["verification"]["before"]["duplicate_entries"], 1)
            self.assertEqual(result["verification"]["after"]["duplicate_entries"], 0)
            self.assertFalse(result["network_used"])
            self.assertFalse(result["generated_code_executed"])
            self.assertTrue(result["consent"]["allowed"])
            self.assertFalse(result["authority"]["external_action"]["allowed"])
            self.assertEqual(result["constitutional_preflight"]["immutable_clause_count"], 14)
            self.assertTrue(result["constitutional_preflight"]["unresolved_builder_goal_blocked"])
            self.assertTrue(result["constitutional_preflight"]["silent_license_expansion_blocked"])
            self.assertEqual(result["builder_goal"]["disposition"], "SCHEDULED")
            self.assertIn(
                result["civic_immune"]["finding"],
                {"WATCH", "DEGRADED", "CAPTURE_RISK"},
            )
            self.assertTrue(all(check["passed"] for check in result["ledger_checks"].values()))
            self.assertTrue(Path(result["report_path"]).is_file())


if __name__ == "__main__":
    unittest.main()
