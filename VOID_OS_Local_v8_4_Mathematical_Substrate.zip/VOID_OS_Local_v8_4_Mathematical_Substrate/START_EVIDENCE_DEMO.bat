@echo off
setlocal
cd /d "%~dp0"
set "VOID_PY="
py -3 -c "import sys; assert sys.version_info >= (3,10)" >nul 2>&1 && set "VOID_PY=py -3"
if not defined VOID_PY python -c "import sys; assert sys.version_info >= (3,10)" >nul 2>&1 && set "VOID_PY=python"
if not defined VOID_PY python3 -c "import sys; assert sys.version_info >= (3,10)" >nul 2>&1 && set "VOID_PY=python3"
if not defined VOID_PY (
  echo Python 3.10 or newer was not found.
  echo Install Python from python.org and enable "Add Python to PATH".
  pause
  exit /b 1
)
%VOID_PY% run_evidence_demo.py
if errorlevel 1 pause
