# VOID OS Φ∞ Mathematical Substrate

The mathematical kernel is installed at `void_os.math_kernel`. It is deliberately
separate from `void_os.kernel`, which remains the host security, path, witness,
and configuration layer.

## Responsibilities

- deterministic null-state transitions;
- polarity, ternary deepening, cube-root folding, digital roots, and triangular transforms;
- Reality Veto validation before state mutation;
- append-only SQLite evidence ledger with SHA-256 lineage chaining;
- normalization to zero without deleting history;
- explicit separation of symbolic correspondences from empirical claims.

## Python API

```python
from void_os.math_kernel import NullKernel, TransitionRequest

kernel = NullKernel("data/math_kernel.db")
kernel.boot()
decision, state = kernel.apply(TransitionRequest("polarize", 1))
valid, errors = kernel.ledger.verify()
```

## Interfaces

- `START_MATH_KERNEL.bat`: local interactive shell
- `START_MATH_DASHBOARD.bat`: Tkinter dashboard
- `VERIFY_MATH_KERNEL.bat`: isolated subsystem verification

## Boundary

The substrate is an executable symbolic and numerical model. It does not treat
symbolic equivalences as scientific identities. Empirical claims remain subject
to the wider VOID OS evidence, constitutional, and governance systems.
