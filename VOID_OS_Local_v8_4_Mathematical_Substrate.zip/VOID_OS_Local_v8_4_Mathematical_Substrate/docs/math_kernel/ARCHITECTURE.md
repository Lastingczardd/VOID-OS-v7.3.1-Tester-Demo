# Architecture Contract

## Interface Layer
Human-facing language, CLI, GUI, and mythographic presentation.

## Continuous Will
Scores candidate actions, but cannot bypass constraints.

## Reality Veto
Rejects unsupported claims, malformed operations, unsafe recursion, and evidence-free observations.

## Null Kernel
Owns the canonical state. Every mutation is deterministic and journaled.

## Evidence Ledger
Append-only SQLite records chained by SHA-256. This is tamper-evident, not magically tamper-proof.

## Future Agent Boundary
Agents propose actions. They never directly mutate canonical state, memory, or code.
