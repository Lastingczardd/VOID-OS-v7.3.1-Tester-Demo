# VOID OS Φ∞ Roadmap

## v8.0 — Mathematical Kernel
- Deterministic state machine
- Formal/symbolic boundary
- Evidence ledger
- Hash-chain verification
- Reality Veto
- CLI and dashboard

## v8.1 — Agent Runtime
- Local Ollama adapter
- Typed agent contracts
- Tool permission manifests
- Per-agent memory boundaries
- Dry-run and approval gates
- No agent may write directly to the evidence ledger

## v8.2 — Garden Memory
- Session, working, long-term, and archive memory
- Consent-aware retention policies
- Deletion receipts
- Derived-data and embedding lineage
- Retrieval confidence and source display

## v8.3 — Forge
- Proposal → patch → test → review → accept/reject pipeline
- Sandboxed code execution
- Reversible upgrades
- Benchmark deltas
- Failed experiments retained as evidence

## v8.4 — Longship
- Plugin and protocol system
- Win-KeX/Kali bridge with explicit permissions
- Import/export capsules
- Signed manifests
- Offline-first package exchange

## v8.5 — Steward Console
- Operator dashboard
- Risk, evidence, memory, and lineage views
- Constitutional rule editor
- Approval queues
- Repair and rollback controls

## Non-negotiable invariants
1. Symbolic language never substitutes for test results.
2. State reset never silently erases history.
3. Autonomous changes remain reversible.
4. Every durable memory has provenance and retention rules.
5. The operator chooses direction; reality verifies claims.
