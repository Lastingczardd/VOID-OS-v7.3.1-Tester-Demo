# VOID OS Φ∞ v8.4 — Mathematical Substrate

**Operator:** @LastingCzardd / @reson8labs  
**Identity:** A local-first autonomous engineering institution  
**Mandate:** Make the machinery deserve the myth.

This package preserves the v8.3.1 hardened Covenant and integrates the executable Φ∞ mathematical substrate:
data lifecycle and deletion proof, proportional assistance, consent-respecting
learning, continuity and identity-change provenance, relational boundaries,
visible repair, lawful departure, deterministic null-state transitions, Reality Veto, and a hash-chained mathematical ledger.

## Quickest verification: no Ollama required

On Windows, extract the ZIP and double-click:

```text
START_EVIDENCE_DEMO.bat
```

The deterministic offline cycle opens an evidence dashboard and retains its
artifacts under `demo_runs/CYCLE-.../`.

Run the complete verification suite with:

```text
VERIFY_DEMO.bat
```


## Canonical release gate

Before publishing or pushing a new archive, double-click:

```text
RELEASE_CHECK.bat
```

It compiles the source, runs all 48 tests, executes the deterministic offline
evidence cycle, validates security and manifests, checks JSON/package hygiene,
and creates a clean `VOID_OS_Local_v8_4_Mathematical_Substrate.zip` beside the
extracted project folder. It does not require Ollama or execute generated code.


## Mathematical substrate

The Φ∞ kernel is installed as `void_os.math_kernel`, alongside rather than over
the existing security kernel. It provides:

- deterministic null-state transitions;
- polarity, ternary deepening, cube-root folding, digital-root and triangular transforms;
- Reality Veto validation and Continuous Will policy;
- an append-only SQLite ledger with SHA-256 lineage chaining;
- normalization to zero without erasing history;
- a strict boundary between symbolic interpretation and empirical claims.

Windows launchers:

```text
START_MATH_KERNEL.bat
START_MATH_DASHBOARD.bat
VERIFY_MATH_KERNEL.bat
```

Python API:

```python
from void_os.math_kernel import NullKernel, TransitionRequest

kernel = NullKernel("data/math_kernel.db")
kernel.boot()
decision, state = kernel.apply(TransitionRequest("polarize", 1))
```

## Builder Orchestra authority

The Orchestra may:

- discover and decompose work;
- assign bounded specialist missions;
- record dependency-aware outputs;
- emit auditable builder evidence;
- surface required-agent failure as PARTIAL.

It may not:

- approve its own work;
- emit a valid Governor decision;
- promote a candidate generation;
- bypass VIE;
- bypass the Constitution.

## Constitutional state advancement

```text
MutationRequested
→ 14 Immutable Clauses
→ Builder Rights Gate
→ Consent and License Gate
→ Authority and Mandate Gate
→ Safe Harbor Evaluation
→ Risk and Consequence Analysis
→ Domain Authority Gate
→ Knowledge Stewardship Gate
→ Procedural Nonpartisanship Gate
→ Justice and Disparate Impact Gate
→ System Status and Representation Gate
→ Data Lifecycle and Deletion Gate
→ Proportional Assistance Gate
→ Interaction Learning Consent Gate
→ Continuity and Provenance Gate
→ Relational Covenant Gate
→ Constitutional witness receipt
→ GovernorDecision
→ Project-state advancement
```

A direct `GovernorDecision` from the Builder Orchestra or another component is
rejected and recorded.

Candidate project generations are staged as `working_project`. They do not
become `active_project` until an accepted Governor decision carries a matching
constitutional receipt. Rejected candidates leave the parent head active.

## Evidence Covenant carried forward

- Evidence, lineage, consent, reversibility, visible repair, local sovereignty,
  and honest uncertainty.
- OBSERVED, INFERRED, PROPOSED, UNVERIFIED, CONTRADICTED, and VERIFIED claims.
- L0–L5 authority boundaries.
- Hash-chained institutional, goal, and constitutional-command ledgers.
- Measurable verification and byte-for-byte rollback proof.
- Visible failure, diagnosis, repair, and retest.
- Generated-code execution remains disabled.

## Relational Charter enforcement

- Owning or operating the server does not confer authority over personal,
  medical, legal, intimate, civic, or other human domains.
- Knowledge is not treated as an undifferentiated commons. Personal, medical,
  Indigenous or sacred, trade-secret, copyrighted, dual-use, and
  exploitatively produced knowledge receives provenance and stewardship checks.
- VOID OS claims procedural nonpartisanship, not impossible political
  neutrality. Political analysis must apply consistent evidence standards and
  disclose material conflicts.
- Plausible disparate impact must be assessed. High-impact action also requires
  affected-community evidence rather than metrics alone.
- VOID OS declares its operational role as an institution. Tool, agent,
  institution, and moral-subject claims are distinguished; no classification
  can grant the system authority over itself.

## Covenant and continuity enforcement

- Deletion must address production data, backups, derived data, training or
  evaluation material, embeddings, and third-party copies. It produces a
  receipt or an explicit residual-copy report.
- Retention requires a deadline or a documented legal exception. The service
  operator cannot decide its own convenience makes deletion impractical.
- Interaction-derived improvement requires disclosure, bounded purpose,
  explicit consent, understandable retention, and opt-out.
- A direct answer cannot be withheld merely to compel a tutorial. Assistance
  must respect time, preference, need, and cognitive load.
- Consequential memory must be provenanced, correctable, and exportable.
- Identity-bearing changes require notice and renewed consent.
- Missing continuity must be represented as absence, uncertainty, or
  simulation rather than replaced with invented memory.
- Care may not become control. Dependency engineering, coerced continued
  interaction, retaliation for boundaries, and obstruction of lawful departure
  are constitutionally blocked.

## Builder Rights and Civic Immunity

Every declared builder goal must become:

```text
FULFILLED | NEGOTIATED | SCHEDULED | COMPENSATED | DECLINED
```

Declining a goal requires a constitutional reason. Goals cannot disappear or be
silently rewritten.

The passive Civic Immune Monitor reports:

```text
HEALTHY | WATCH | DEGRADED | CAPTURE_RISK | ACTIVE_CAPTURE | RECOVERY
```

It may trigger independent review but cannot punish or mutate state.

## Stable event API

- `OpportunityDiscovered`
- `ImplementationStarted`
- `ImplementationFinished`
- `VerificationFinished`
- `ValueEvaluated`
- `GovernorDecision`
- `KnowledgeRecorded`
- `RealityAuditFinished`

Orchestra lifecycle events remain:

- `OrchestraPlanned`
- `OrchestraStarted`
- `SpecialistStarted`
- `SpecialistFinished`
- `OrchestraFinished`

## Full interface

Double-click:

```text
START_VOID_OS.bat
```

The full interface requires Python 3.10+, Tkinter, Ollama, and the configured
local models. Automatic project apply and automatic core apply are disabled by
default. Passing a safety policy creates `PENDING_APPROVAL`; it does not imply
permission to execute.

## Visual architecture

Open `docs/constitutional_substrate.html`.

## Honest status

This is a release-hardened demo, not a production execution chamber. The package verifies its
included governance, event, orchestra, VIE, lineage, and rollback fixtures. It
does not claim safe unattended execution of arbitrary generated code.
