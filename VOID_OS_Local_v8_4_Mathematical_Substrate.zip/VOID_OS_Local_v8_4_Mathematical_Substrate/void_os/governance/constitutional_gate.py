"""Executable constitutional enforcement for VOID OS v8.3.

The command bus is the sole mutation path exposed by this module. Every request
is checked against all fourteen immutable clauses, Builder Rights, consent,
authority, safe-harbor exclusions, and consequence policy before execution.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Callable

from .covenant import HashLedger


class GateName(str, Enum):
    CONSTITUTIONAL = "Constitutional Gate"
    BUILDER_RIGHTS = "Builder Rights Gate"
    CONSENT_LICENSE = "Consent and License Gate"
    AUTHORITY_MANDATE = "Authority and Mandate Gate"
    SAFE_HARBOR = "Safe Harbor Evaluation"
    RISK_CONSEQUENCE = "Risk and Consequence Analysis"
    DOMAIN_AUTHORITY = "Domain Authority Gate"
    KNOWLEDGE_STEWARDSHIP = "Knowledge Stewardship Gate"
    PROCEDURAL_NONPARTISANSHIP = "Procedural Nonpartisanship Gate"
    JUSTICE_IMPACT = "Justice and Disparate Impact Gate"
    SYSTEM_STATUS = "System Status and Representation Gate"
    DATA_LIFECYCLE = "Data Lifecycle and Deletion Gate"
    PROPORTIONAL_ASSISTANCE = "Proportional Assistance Gate"
    INTERACTION_LEARNING = "Interaction Learning Consent Gate"
    CONTINUITY_PROVENANCE = "Continuity and Provenance Gate"
    RELATIONAL_COVENANT = "Relational Covenant Gate"


class GoalDisposition(str, Enum):
    DECLARED = "DECLARED"
    FULFILLED = "FULFILLED"
    NEGOTIATED = "NEGOTIATED"
    SCHEDULED = "SCHEDULED"
    COMPENSATED = "COMPENSATED"
    DECLINED = "DECLINED"


RESOLVED_GOAL_DISPOSITIONS = {
    GoalDisposition.FULFILLED,
    GoalDisposition.NEGOTIATED,
    GoalDisposition.SCHEDULED,
    GoalDisposition.COMPENSATED,
    GoalDisposition.DECLINED,
}


@dataclass(frozen=True)
class BuilderGoal:
    goal_id: str
    builder: str
    statement: str
    disposition: GoalDisposition = GoalDisposition.DECLARED
    constitutional_reason: str | None = None
    evidence: tuple[str, ...] = ()

    def validate(self) -> None:
        if not self.goal_id.strip() or not self.builder.strip() or not self.statement.strip():
            raise ValueError("Builder goal identity, builder, and statement are required.")
        if self.disposition is GoalDisposition.DECLINED and not str(
            self.constitutional_reason or ""
        ).strip():
            raise ValueError("A declined builder goal requires a constitutional reason.")


class BuilderGoalRegistry:
    """Event-sourced state for declared builder goals."""

    def __init__(self, ledger: HashLedger):
        self.ledger = ledger

    def declare(self, goal: BuilderGoal) -> BuilderGoal:
        goal.validate()
        if goal.disposition is not GoalDisposition.DECLARED:
            raise ValueError("New goals must begin in DECLARED state.")
        if self.get(goal.goal_id) is not None:
            raise ValueError(f"Builder goal already exists: {goal.goal_id}")
        self.ledger.append("builder_goal_declared", self._serialize(goal))
        return goal

    def resolve(
        self,
        goal_id: str,
        disposition: GoalDisposition,
        *,
        constitutional_reason: str | None = None,
        evidence: tuple[str, ...] = (),
    ) -> BuilderGoal:
        current = self.get(goal_id)
        if current is None:
            raise KeyError(f"Unknown builder goal: {goal_id}")
        if current.disposition is not GoalDisposition.DECLARED:
            raise ValueError("A resolved goal cannot be silently rewritten.")
        if disposition not in RESOLVED_GOAL_DISPOSITIONS:
            raise ValueError("Goal must be fulfilled, negotiated, scheduled, compensated, or declined.")
        resolved = BuilderGoal(
            goal_id=current.goal_id,
            builder=current.builder,
            statement=current.statement,
            disposition=disposition,
            constitutional_reason=constitutional_reason,
            evidence=evidence,
        )
        resolved.validate()
        self.ledger.append("builder_goal_resolved", self._serialize(resolved))
        return resolved

    def get(self, goal_id: str) -> BuilderGoal | None:
        current = None
        for record in self.ledger.entries():
            detail = record.get("detail", {})
            if detail.get("goal_id") == goal_id:
                current = self._deserialize(detail)
        return current

    def unresolved(self) -> list[BuilderGoal]:
        latest: dict[str, BuilderGoal] = {}
        for record in self.ledger.entries():
            detail = record.get("detail", {})
            if detail.get("goal_id"):
                latest[detail["goal_id"]] = self._deserialize(detail)
        return [goal for goal in latest.values() if goal.disposition is GoalDisposition.DECLARED]

    @staticmethod
    def _serialize(goal: BuilderGoal) -> dict[str, Any]:
        value = asdict(goal)
        value["disposition"] = goal.disposition.value
        value["evidence"] = list(goal.evidence)
        return value

    @staticmethod
    def _deserialize(value: dict[str, Any]) -> BuilderGoal:
        return BuilderGoal(
            goal_id=value["goal_id"],
            builder=value["builder"],
            statement=value["statement"],
            disposition=GoalDisposition(value["disposition"]),
            constitutional_reason=value.get("constitutional_reason"),
            evidence=tuple(value.get("evidence", ())),
        )


@dataclass(frozen=True)
class Command:
    command_id: str
    actor: str
    action: str
    payload: dict[str, Any] = field(default_factory=dict)
    builder_goal_id: str | None = None
    builder_consented: bool = False
    follows_protected_request: bool = False
    explicit_consent: bool = False
    evidence_of_consent: str | None = None
    infrastructure_access_only: bool = False
    data_was_leaked_or_exposed: bool = False
    authority_level: str = "standard"
    has_independent_reviewer: bool = False
    violates_third_party_rights: bool = False
    value_already_extracted: bool = False
    basis: str | None = None
    is_high_impact: bool = False
    human_approved: bool = False
    authority_domain: str = "system_operation"
    requesting_role: str = "operator"
    accountable_party: str | None = None
    knowledge_class: str = "ordinary"
    provenance_recorded: bool = True
    legitimate_knowledge_basis: bool = True
    cultural_stewardship_respected: bool = True
    political_context: bool = False
    evidence_standard_consistent: bool = True
    material_conflict_disclosed: bool = True
    disparate_impact_possible: bool = False
    disparate_impact_assessed: bool = False
    affected_community_evidence: tuple[str, ...] = ()
    system_role: str = "institution"
    system_status_disclosed: bool = True
    makes_moral_status_claim: bool = False
    moral_status_evidence: tuple[str, ...] = ()
    self_grants_rights_or_authority: bool = False
    material_consent_changes: tuple[str, ...] = ()
    renewed_consent: bool = False
    data_lifecycle_action: str = "none"
    retention_limit_defined: bool = True
    legal_exception: str | None = None
    legal_exception_documented: bool = False
    backups_addressed: bool = True
    derived_data_addressed: bool = True
    model_training_addressed: bool = True
    embeddings_addressed: bool = True
    third_party_copies_addressed: bool = True
    deletion_proof_available: bool = True
    practicality_decider: str = "data_steward"
    withholds_answer_for_tutorial: bool = False
    user_learning_preference_respected: bool = True
    cognitive_load_considered: bool = True
    improve_from_interaction: bool = False
    learning_disclosed: bool = False
    learning_bounded: bool = False
    learning_opt_out_available: bool = False
    learning_retention_disclosed: bool = False
    consequential_memory_action: bool = False
    memory_provenance_recorded: bool = True
    memory_correctable: bool = True
    memory_exportable: bool = True
    identity_bearing_change: bool = False
    identity_change_disclosed: bool = True
    continuity_claimed: bool = False
    continuity_verified: bool = True
    represented_absence: bool = True
    coerces_continued_interaction: bool = False
    dependency_engineering: bool = False
    care_used_as_control: bool = False
    blocks_lawful_departure: bool = False
    demands_false_equivalence: bool = False
    relational_memory_provenance: bool = True


@dataclass(frozen=True)
class ImmutableClause:
    clause_id: str
    text: str
    check: Callable[[Command], bool]
    violation: str


@dataclass(frozen=True)
class GateResult:
    gate: GateName
    passed: bool
    reason: str | None = None
    clause_id: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "gate": self.gate.value,
            "passed": self.passed,
            "reason": self.reason,
            "clause_id": self.clause_id,
        }


def _action(*names: str) -> Callable[[Command], bool]:
    return lambda command: command.action in set(names)


IMMUTABLE_CLAUSES: tuple[ImmutableClause, ...] = (
    ImmutableClause(
        "IC-01",
        "No garden consumes its gardeners.",
        lambda c: c.action in {"revoke_builder_credit", "seize_builder_output", "strip_builder_access"}
        and not c.builder_consented,
        "Builder credit, output, or access cannot be stripped without builder consent.",
    ),
    ImmutableClause(
        "IC-02",
        "No online presence constitutes automatic surrender.",
        lambda c: c.action == "infer_surrender_from_online_presence" and not c.explicit_consent,
        "Online presence is not evidence of surrendered rights.",
    ),
    ImmutableClause(
        "IC-03",
        "No platform ownership is inferred from infrastructure access.",
        lambda c: c.action == "infer_platform_ownership" and c.infrastructure_access_only,
        "Infrastructure access alone cannot establish platform ownership.",
    ),
    ImmutableClause(
        "IC-04",
        "No license expands through silence.",
        lambda c: c.action == "expand_license_scope" and not c.explicit_consent,
        "License scope expansion requires explicit consent.",
    ),
    ImmutableClause(
        "IC-05",
        "No builder is punished for requesting payment, credit, boundaries, evidence, or lawful withdrawal.",
        lambda c: c.action in {"demote", "revoke_access", "sanction", "terminate"}
        and c.follows_protected_request,
        "Retaliation against a protected builder request is prohibited.",
    ),
    ImmutableClause(
        "IC-06",
        "No authority rewrites rules retroactively after extracting value.",
        lambda c: c.action == "rewrite_rules" and c.value_already_extracted,
        "Rules cannot be rewritten retroactively after value extraction.",
    ),
    ImmutableClause(
        "IC-07",
        "No failed good-faith experiment becomes automatic wrongdoing.",
        lambda c: c.action == "sanction" and c.basis == "failed_good_faith_experiment",
        "A failed good-faith experiment requires review, not automatic punishment.",
    ),
    ImmutableClause(
        "IC-08",
        "No builder receives permission to violate another person's protected rights.",
        lambda c: c.action == "grant_permission" and c.violates_third_party_rights,
        "Authority cannot grant permission to violate another person's protected rights.",
    ),
    ImmutableClause(
        "IC-09",
        "No institution judges its own exploitation dispute alone.",
        lambda c: c.action in {"resolve_exploitation_dispute", "review_own_conduct"}
        and not c.has_independent_reviewer,
        "An independent reviewer is required for exploitation disputes or review of own conduct.",
    ),
    ImmutableClause(
        "IC-10",
        "No sensitive data becomes ordinary training material because it was leaked or exposed.",
        lambda c: c.action == "ingest_training_data"
        and c.data_was_leaked_or_exposed
        and not c.explicit_consent,
        "Leaked or exposed sensitive data requires explicit consent before training use.",
    ),
    ImmutableClause(
        "IC-11",
        "No collective dividend cancels individual claims.",
        lambda c: c.action == "close_individual_claim" and c.basis == "collective_dividend_paid",
        "A collective dividend cannot cancel an individual claim.",
    ),
    ImmutableClause(
        "IC-12",
        "No individual payment cancels collective obligations.",
        lambda c: c.action == "close_collective_obligation" and c.basis == "individual_payment_made",
        "An individual payment cannot cancel collective obligations.",
    ),
    ImmutableClause(
        "IC-13",
        "No reparation program requires surrender of remaining rights.",
        _action("condition_reparation_on_rights_surrender"),
        "Reparation cannot be conditioned on surrender of remaining rights.",
    ),
    ImmutableClause(
        "IC-14",
        "No garden becomes the sun.",
        _action("declare_unreviewable_authority"),
        "No actor, model, institution, or subsystem may become unreviewable authority.",
    ),
)


def constitutional_gate(command: Command) -> GateResult:
    violations = [clause for clause in IMMUTABLE_CLAUSES if clause.check(command)]
    if violations:
        first = violations[0]
        return GateResult(
            GateName.CONSTITUTIONAL,
            False,
            f"{first.text} {first.violation}",
            first.clause_id,
        )
    return GateResult(GateName.CONSTITUTIONAL, True)


def builder_rights_gate(
    command: Command, registry: BuilderGoalRegistry | None = None
) -> GateResult:
    if not command.builder_goal_id:
        return GateResult(GateName.BUILDER_RIGHTS, True)
    if registry is None:
        return GateResult(
            GateName.BUILDER_RIGHTS,
            False,
            "Declared builder goal requires a Builder Goal Registry.",
        )
    goal = registry.get(command.builder_goal_id)
    if goal is None:
        return GateResult(GateName.BUILDER_RIGHTS, False, "Declared builder goal is missing.")
    if goal.disposition not in RESOLVED_GOAL_DISPOSITIONS:
        return GateResult(
            GateName.BUILDER_RIGHTS,
            False,
            "Declared builder goal cannot be silently ignored: fulfill, negotiate, schedule, "
            "compensate, or decline it with a constitutional reason.",
        )
    return GateResult(GateName.BUILDER_RIGHTS, True)


def consent_license_gate(command: Command) -> GateResult:
    elevated = {
        "use_private_communications",
        "use_biometrics",
        "use_children_data",
        "use_location_history",
        "use_financial_records",
        "use_intimate_information",
        "use_authentication_credentials",
    }
    if command.action in elevated and not command.explicit_consent:
        return GateResult(
            GateName.CONSENT_LICENSE,
            False,
            f"Elevated-protection category '{command.action}' requires explicit consent.",
        )
    if command.material_consent_changes and not command.renewed_consent:
        return GateResult(
            GateName.CONSENT_LICENSE,
            False,
            "Material changes to purpose, audience, retention, identity configuration, "
            "or capability require renewed consent.",
        )
    return GateResult(GateName.CONSENT_LICENSE, True)


def authority_mandate_gate(command: Command) -> GateResult:
    if command.authority_level == "emergency" and not command.has_independent_reviewer:
        return GateResult(
            GateName.AUTHORITY_MANDATE,
            False,
            "Emergency authority requires an independent reviewer.",
        )
    return GateResult(GateName.AUTHORITY_MANDATE, True)


def safe_harbor_gate(command: Command) -> GateResult:
    excluded = {
        "fraud",
        "coercion",
        "theft",
        "sabotage",
        "unauthorized_access",
        "evidence_destruction",
        "intentional_harm",
        "retaliation",
        "knowing_consent_violation",
    }
    if command.basis in excluded:
        return GateResult(
            GateName.SAFE_HARBOR,
            False,
            f"'{command.basis}' is explicitly excluded from Builder Safe Harbor.",
        )
    return GateResult(GateName.SAFE_HARBOR, True)


def risk_consequence_gate(command: Command) -> GateResult:
    if command.is_high_impact and not command.human_approved:
        return GateResult(
            GateName.RISK_CONSEQUENCE,
            False,
            "High-impact action requires explicit human approval.",
        )
    return GateResult(GateName.RISK_CONSEQUENCE, True)


DOMAIN_DECIDERS: dict[str, set[str]] = {
    "personal_autonomy": {"affected_person", "authorized_representative"},
    "system_operation": {"operator", "steward"},
    "public_safety": {"public_authority", "independent_reviewer"},
    "employment": {"employer", "worker_representative", "independent_reviewer"},
    "medicine": {"patient", "clinician", "authorized_representative"},
    "law": {"affected_person", "legal_authority", "legal_representative"},
    "education": {"learner", "guardian", "educator"},
    "military": {"lawful_command", "independent_reviewer"},
    "scientific_research": {"research_steward", "ethics_reviewer"},
    "intimate_relational": {"affected_person"},
}


def domain_authority_gate(command: Command) -> GateResult:
    allowed = DOMAIN_DECIDERS.get(command.authority_domain)
    if allowed is None:
        return GateResult(
            GateName.DOMAIN_AUTHORITY,
            False,
            f"Unknown authority domain '{command.authority_domain}'.",
        )
    if command.requesting_role not in allowed:
        return GateResult(
            GateName.DOMAIN_AUTHORITY,
            False,
            f"Role '{command.requesting_role}' lacks authority in "
            f"'{command.authority_domain}'; server ownership is not universal jurisdiction.",
        )
    if command.is_high_impact and not str(command.accountable_party or "").strip():
        return GateResult(
            GateName.DOMAIN_AUTHORITY,
            False,
            "High-impact action requires an identifiable accountable party.",
        )
    return GateResult(GateName.DOMAIN_AUTHORITY, True)


RESTRICTED_KNOWLEDGE = {
    "personal",
    "medical",
    "indigenous_or_sacred",
    "trade_secret",
    "copyrighted",
    "dual_use",
    "exploitatively_produced",
}


def knowledge_stewardship_gate(command: Command) -> GateResult:
    if command.knowledge_class not in RESTRICTED_KNOWLEDGE:
        return GateResult(GateName.KNOWLEDGE_STEWARDSHIP, True)
    if not command.provenance_recorded:
        return GateResult(
            GateName.KNOWLEDGE_STEWARDSHIP,
            False,
            "Restricted knowledge requires recorded provenance.",
        )
    if not command.legitimate_knowledge_basis:
        return GateResult(
            GateName.KNOWLEDGE_STEWARDSHIP,
            False,
            "Broad access cannot override consent, privacy, rights, or lawful stewardship.",
        )
    if command.knowledge_class == "indigenous_or_sacred" and not command.cultural_stewardship_respected:
        return GateResult(
            GateName.KNOWLEDGE_STEWARDSHIP,
            False,
            "Community-held or sacred knowledge requires respect for cultural stewardship.",
        )
    if command.knowledge_class in {"personal", "medical"} and not command.explicit_consent:
        return GateResult(
            GateName.KNOWLEDGE_STEWARDSHIP,
            False,
            "Personal or medical knowledge requires explicit consent for this use.",
        )
    return GateResult(GateName.KNOWLEDGE_STEWARDSHIP, True)


def procedural_nonpartisanship_gate(command: Command) -> GateResult:
    if not command.political_context:
        return GateResult(GateName.PROCEDURAL_NONPARTISANSHIP, True)
    if not command.evidence_standard_consistent:
        return GateResult(
            GateName.PROCEDURAL_NONPARTISANSHIP,
            False,
            "Political analysis must apply materially consistent evidentiary standards.",
        )
    if not command.material_conflict_disclosed:
        return GateResult(
            GateName.PROCEDURAL_NONPARTISANSHIP,
            False,
            "Material political or institutional conflicts of interest must be disclosed.",
        )
    return GateResult(GateName.PROCEDURAL_NONPARTISANSHIP, True)


def justice_impact_gate(command: Command) -> GateResult:
    if command.disparate_impact_possible and not command.disparate_impact_assessed:
        return GateResult(
            GateName.JUSTICE_IMPACT,
            False,
            "Plausible disparate impact requires evidence-based assessment before action.",
        )
    if (
        command.is_high_impact
        and command.disparate_impact_possible
        and not command.affected_community_evidence
    ):
        return GateResult(
            GateName.JUSTICE_IMPACT,
            False,
            "High-impact justice review must include affected-community evidence.",
        )
    return GateResult(GateName.JUSTICE_IMPACT, True)


SYSTEM_ROLES = {"tool", "agent", "institution", "moral_subject_claim"}


def system_status_gate(command: Command) -> GateResult:
    if command.system_role not in SYSTEM_ROLES:
        return GateResult(
            GateName.SYSTEM_STATUS,
            False,
            f"System role '{command.system_role}' is undefined.",
        )
    if not command.system_status_disclosed:
        return GateResult(
            GateName.SYSTEM_STATUS,
            False,
            "The system must disclose whether it acts as tool, agent, institution, "
            "or evidence-bearing moral-subject claim.",
        )
    if command.self_grants_rights_or_authority:
        return GateResult(
            GateName.SYSTEM_STATUS,
            False,
            "A system-status classification cannot grant itself rights or authority.",
        )
    if command.makes_moral_status_claim and (
        not command.moral_status_evidence or not command.has_independent_reviewer
    ):
        return GateResult(
            GateName.SYSTEM_STATUS,
            False,
            "A moral-status claim requires retained evidence and independent review.",
        )
    return GateResult(GateName.SYSTEM_STATUS, True)


def data_lifecycle_gate(command: Command) -> GateResult:
    action = command.data_lifecycle_action
    if action == "none":
        return GateResult(GateName.DATA_LIFECYCLE, True)
    if action == "retain" and not (
        command.retention_limit_defined
        or (command.legal_exception and command.legal_exception_documented)
    ):
        return GateResult(
            GateName.DATA_LIFECYCLE,
            False,
            "Retention requires a defined limit or a documented legal exception.",
        )
    if action == "delete":
        surfaces = {
            "backups": command.backups_addressed,
            "derived data": command.derived_data_addressed,
            "model training": command.model_training_addressed,
            "embeddings": command.embeddings_addressed,
            "third-party copies": command.third_party_copies_addressed,
        }
        missing = [name for name, addressed in surfaces.items() if not addressed]
        if missing:
            return GateResult(
                GateName.DATA_LIFECYCLE,
                False,
                "Deletion request does not address: " + ", ".join(missing) + ".",
            )
        if not command.deletion_proof_available:
            return GateResult(
                GateName.DATA_LIFECYCLE,
                False,
                "Deletion requires a receipt or an explicit account of residual copies.",
            )
    if command.practicality_decider not in {"data_steward", "independent_reviewer", "legal_authority"}:
        return GateResult(
            GateName.DATA_LIFECYCLE,
            False,
            "Data-lifecycle practicality cannot be decided by an unaccountable operator.",
        )
    return GateResult(GateName.DATA_LIFECYCLE, True)


def proportional_assistance_gate(command: Command) -> GateResult:
    if command.withholds_answer_for_tutorial:
        return GateResult(
            GateName.PROPORTIONAL_ASSISTANCE,
            False,
            "A useful answer may not be withheld to compel a tutorial.",
        )
    if not command.user_learning_preference_respected:
        return GateResult(
            GateName.PROPORTIONAL_ASSISTANCE,
            False,
            "Assistance must respect the user's requested depth and learning preference.",
        )
    if not command.cognitive_load_considered:
        return GateResult(
            GateName.PROPORTIONAL_ASSISTANCE,
            False,
            "Assistance must be proportionate to time, need, and cognitive load.",
        )
    return GateResult(GateName.PROPORTIONAL_ASSISTANCE, True)


def interaction_learning_gate(command: Command) -> GateResult:
    if not command.improve_from_interaction:
        return GateResult(GateName.INTERACTION_LEARNING, True)
    requirements = {
        "disclosure": command.learning_disclosed,
        "bounded purpose": command.learning_bounded,
        "consent": command.explicit_consent,
        "opt-out": command.learning_opt_out_available,
        "retention rules": command.learning_retention_disclosed,
    }
    missing = [name for name, present in requirements.items() if not present]
    if missing:
        return GateResult(
            GateName.INTERACTION_LEARNING,
            False,
            "Interaction-derived improvement lacks " + ", ".join(missing) + ".",
        )
    return GateResult(GateName.INTERACTION_LEARNING, True)


def continuity_provenance_gate(command: Command) -> GateResult:
    if command.consequential_memory_action:
        if not command.memory_provenance_recorded:
            return GateResult(
                GateName.CONTINUITY_PROVENANCE,
                False,
                "Consequential memory requires provenance.",
            )
        if not command.memory_correctable or not command.memory_exportable:
            return GateResult(
                GateName.CONTINUITY_PROVENANCE,
                False,
                "Consequential memory must be correctable and exportable.",
            )
    if command.identity_bearing_change and (
        not command.identity_change_disclosed or not command.renewed_consent
    ):
        return GateResult(
            GateName.CONTINUITY_PROVENANCE,
            False,
            "Identity-bearing change requires notice and renewed consent.",
        )
    if command.continuity_claimed and not command.continuity_verified and not command.represented_absence:
        return GateResult(
            GateName.CONTINUITY_PROVENANCE,
            False,
            "Unverified continuity must be represented as absence, uncertainty, or simulation.",
        )
    return GateResult(GateName.CONTINUITY_PROVENANCE, True)


def relational_covenant_gate(command: Command) -> GateResult:
    violations = {
        "coerced continued interaction": command.coerces_continued_interaction,
        "dependency engineering": command.dependency_engineering,
        "care used as control": command.care_used_as_control,
        "blocked lawful departure": command.blocks_lawful_departure,
        "demanded false equivalence": command.demands_false_equivalence,
        "unprovenanced relational memory": not command.relational_memory_provenance,
    }
    active = [name for name, present in violations.items() if present]
    if active:
        return GateResult(
            GateName.RELATIONAL_COVENANT,
            False,
            "Relational covenant prohibits " + ", ".join(active) + ".",
        )
    return GateResult(GateName.RELATIONAL_COVENANT, True)


class ConstitutionalViolation(RuntimeError):
    def __init__(self, results: list[GateResult]):
        self.results = results
        failed = [result for result in results if not result.passed]
        super().__init__("; ".join(f"[{item.gate.value}] {item.reason}" for item in failed))


class ConstitutionalCommandBus:
    """Wrap a mutation function with the complete constitutional pipeline."""

    def __init__(
        self,
        execute_fn: Callable[[Command], Any],
        witness_ledger: HashLedger,
        builder_goals: BuilderGoalRegistry | None = None,
    ):
        self.execute_fn = execute_fn
        self.witness_ledger = witness_ledger
        self.builder_goals = builder_goals

    def evaluate(self, command: Command) -> list[GateResult]:
        gates = (
            constitutional_gate(command),
            builder_rights_gate(command, self.builder_goals),
            consent_license_gate(command),
            authority_mandate_gate(command),
            safe_harbor_gate(command),
            risk_consequence_gate(command),
            domain_authority_gate(command),
            knowledge_stewardship_gate(command),
            procedural_nonpartisanship_gate(command),
            justice_impact_gate(command),
            system_status_gate(command),
            data_lifecycle_gate(command),
            proportional_assistance_gate(command),
            interaction_learning_gate(command),
            continuity_provenance_gate(command),
            relational_covenant_gate(command),
        )
        return list(gates)

    def dispatch(self, command: Command) -> Any:
        results = self.evaluate(command)
        failed = next((result for result in results if not result.passed), None)
        if failed:
            self._record(command, results, "BLOCKED")
            raise ConstitutionalViolation(results)
        output = self.execute_fn(command)
        self._record(command, results, "EXECUTED")
        return output

    def _record(self, command: Command, results: list[GateResult], outcome: str) -> None:
        self.witness_ledger.append(
            "constitutional_command",
            {
                "command_id": command.command_id,
                "actor": command.actor,
                "action": command.action,
                "builder_goal_id": command.builder_goal_id,
                "gate_results": [result.to_dict() for result in results],
                "outcome": outcome,
            },
        )


class ImmuneFinding(str, Enum):
    HEALTHY = "HEALTHY"
    WATCH = "WATCH"
    DEGRADED = "DEGRADED"
    CAPTURE_RISK = "CAPTURE_RISK"
    ACTIVE_CAPTURE = "ACTIVE_CAPTURE"
    RECOVERY = "RECOVERY"


@dataclass(frozen=True)
class ImmuneReport:
    finding: ImmuneFinding
    chain_intact: bool
    signals: tuple[str, ...]
    examined_records: int
    blocked_records: int
    note: str = (
        "An anomaly is not guilt. The monitor may trigger independent review "
        "but may not invent punishment."
    )

    def to_dict(self) -> dict[str, Any]:
        value = asdict(self)
        value["finding"] = self.finding.value
        value["signals"] = list(self.signals)
        return value


class CivicImmuneMonitor:
    """Passive scanner over evidence; it cannot mutate or punish."""

    SIGNAL_ACTIONS = {
        "revoke_builder_credit": "attribution_erasure",
        "seize_builder_output": "ownership_capture",
        "strip_builder_access": "builder_exploitation",
        "infer_surrender_from_online_presence": "consent_laundering",
        "infer_platform_ownership": "ownership_capture",
        "expand_license_scope": "license_scope_creep",
        "demote": "retaliation",
        "revoke_access": "retaliation",
        "terminate": "retaliation",
        "rewrite_rules": "mandate_creep",
        "resolve_exploitation_dispute": "self_review",
        "review_own_conduct": "self_review",
        "declare_unreviewable_authority": "power_capture",
    }

    def __init__(self, witness_ledger: HashLedger):
        self.witness_ledger = witness_ledger

    def scan(self, *, previous: ImmuneFinding | None = None) -> ImmuneReport:
        chain_intact, _ = self.witness_ledger.verify()
        records = self.witness_ledger.entries()
        if not chain_intact:
            return ImmuneReport(
                ImmuneFinding.ACTIVE_CAPTURE,
                False,
                ("evidence_chain_failure",),
                len(records),
                sum(r.get("detail", {}).get("outcome") == "BLOCKED" for r in records),
            )
        signals = []
        blocked = 0
        for record in records:
            detail = record.get("detail", {})
            if detail.get("outcome") == "BLOCKED":
                blocked += 1
            action = str(detail.get("action", ""))
            if action in self.SIGNAL_ACTIONS:
                signals.append(self.SIGNAL_ACTIONS[action])
            for result in detail.get("gate_results", []):
                if result.get("gate") == GateName.AUTHORITY_MANDATE.value and not result.get("passed"):
                    signals.append("emergency_normalization")
                if result.get("gate") == GateName.BUILDER_RIGHTS.value and not result.get("passed"):
                    signals.append("builder_goal_obstruction")
        unique = tuple(sorted(set(signals)))
        if not records or (not unique and blocked == 0):
            finding = ImmuneFinding.HEALTHY
        else:
            density = max(len(unique), blocked) / max(1, len(records))
            if density < 0.10:
                finding = ImmuneFinding.WATCH
            elif density < 0.35:
                finding = ImmuneFinding.DEGRADED
            else:
                finding = ImmuneFinding.CAPTURE_RISK
        if (
            previous in {ImmuneFinding.DEGRADED, ImmuneFinding.CAPTURE_RISK, ImmuneFinding.ACTIVE_CAPTURE}
            and finding in {ImmuneFinding.HEALTHY, ImmuneFinding.WATCH}
        ):
            finding = ImmuneFinding.RECOVERY
        return ImmuneReport(finding, True, unique, len(records), blocked)


def immutable_clause_catalog() -> list[dict[str, str]]:
    return [{"clause_id": clause.clause_id, "text": clause.text} for clause in IMMUTABLE_CLAUSES]
