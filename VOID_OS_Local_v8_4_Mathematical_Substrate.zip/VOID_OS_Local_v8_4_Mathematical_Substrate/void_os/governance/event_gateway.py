"""Event-driven constitutional gateway for the v8 Builder Orchestra."""
from __future__ import annotations

from pathlib import Path
from typing import Any

from ..core.events import Event, EventBus
from ..core.state import ProjectStateStore
from .constitutional_gate import (
    BuilderGoalRegistry,
    Command,
    ConstitutionalCommandBus,
    ConstitutionalViolation,
)
from .covenant import HashLedger


class ConstitutionalEventGateway:
    """Turn mutation requests into receipted stable events.

    Builder components publish evidence events directly. State-advancing
    GovernorDecision events are protected and can only be emitted by this
    gateway after the complete constitutional pipeline passes.
    """

    PROTECTED_EVENT = "GovernorDecision"

    def __init__(self, bus: EventBus, state: ProjectStateStore, state_root: Path):
        self.bus = bus
        self.state = state
        governance_root = Path(state_root) / "governance"
        self.witness = HashLedger(governance_root / "constitutional_commands.jsonl")
        self.goals = BuilderGoalRegistry(HashLedger(governance_root / "builder_goals.jsonl"))
        self.command_bus = ConstitutionalCommandBus(
            execute_fn=self._execute,
            witness_ledger=self.witness,
            builder_goals=self.goals,
        )
        self.bus.protect(self.PROTECTED_EVENT, self._authorize_protected_event)
        self.bus.subscribe("MutationRequested", self._handle_request)
        self.bus.subscribe(self.PROTECTED_EVENT, self._advance_state)

    def request_governor_decision(
        self,
        report: dict[str, Any],
        *,
        cycle: int,
        actor: str = "long_term_governor",
        builder_goal_id: str | None = None,
        state_changes: dict[str, Any] | None = None,
    ) -> Event:
        return self.bus.emit(
            "MutationRequested",
            {
                "command": {
                    "command_id": f"governor-{cycle}-{report.get('fingerprint', 'unscoped')}",
                    "actor": actor,
                    "action": "advance_project_state",
                    "builder_goal_id": builder_goal_id,
                    "explicit_consent": True,
                    "human_approved": True,
                    "authority_domain": "system_operation",
                    "requesting_role": "steward",
                    "accountable_party": actor,
                    "system_role": "institution",
                    "system_status_disclosed": True,
                },
                "target_event": self.PROTECTED_EVENT,
                "target_payload": {**report, "state_changes": state_changes or {}},
            },
            source=actor,
            cycle=cycle,
        )

    def _handle_request(self, event: Event) -> None:
        payload = event.payload
        command_data = payload.get("command", {})
        target_event = str(payload.get("target_event", ""))
        if target_event != self.PROTECTED_EVENT:
            self.bus.emit(
                "MutationBlocked",
                {
                    "request_event_id": event.event_id,
                    "reason": "Only GovernorDecision may advance state through this gateway.",
                },
                source="constitutional_gateway",
                cycle=event.cycle,
            )
            return
        command = Command(**command_data)
        self._pending = {
            "request_event_id": event.event_id,
            "target_event": target_event,
            "target_payload": dict(payload.get("target_payload", {})),
            "cycle": event.cycle,
        }
        try:
            self.command_bus.dispatch(command)
            self.emit_receipted_decision(event.event_id)
        except ConstitutionalViolation as exc:
            self.bus.emit(
                "MutationBlocked",
                {
                    "request_event_id": event.event_id,
                    "command_id": command.command_id,
                    "gate_results": [result.to_dict() for result in exc.results],
                    "reason": str(exc),
                },
                source="constitutional_gateway",
                cycle=event.cycle,
            )
        finally:
            self._pending = None

    def _execute(self, command: Command) -> dict[str, Any]:
        pending = self._pending
        if not pending:
            raise RuntimeError("No active mutation request.")
        return {
            "command_id": command.command_id,
            "target_event": pending["target_event"],
        }

    def _authorize_protected_event(self, event: Event) -> tuple[bool, str]:
        receipt = str(event.payload.get("constitutional_receipt", ""))
        if event.source != "constitutional_gateway":
            return False, "GovernorDecision must originate at the Constitutional Event Gateway."
        if len(receipt) != 64:
            return False, "GovernorDecision requires a constitutional witness receipt."
        entries = self.witness.entries()
        if not entries or entries[-1].get("sha256") != receipt:
            return False, "GovernorDecision receipt does not match the constitutional witness chain."
        if entries[-1].get("detail", {}).get("outcome") != "EXECUTED":
            return False, "GovernorDecision receipt does not authorize execution."
        return True, "Constitutional receipt verified."

    def _advance_state(self, event: Event) -> None:
        changes = dict(event.payload.get("state_changes", {}))
        changes.setdefault("last_decision", event.payload.get("decision"))
        changes.setdefault("last_vis", event.payload.get("vis"))
        changes.setdefault("predictive", event.payload.get("predictive", {}))
        self.state.apply_governor_decision(
            changes,
            constitutional_receipt=str(event.payload["constitutional_receipt"]),
        )

    def emit_receipted_decision(self, request_event_id: str | None = None) -> Event:
        """Emit the pending decision after command execution has been witnessed."""
        pending = self._pending
        if not pending:
            raise RuntimeError("No completed request is pending.")
        entries = self.witness.entries()
        if not entries:
            raise RuntimeError("Constitutional witness receipt is missing.")
        receipt = entries[-1]["sha256"]
        return self.bus.emit(
            pending["target_event"],
            {
                **pending["target_payload"],
                "constitutional_receipt": receipt,
                "mutation_request_event_id": request_event_id or pending["request_event_id"],
            },
            source="constitutional_gateway",
            cycle=pending["cycle"],
        )
