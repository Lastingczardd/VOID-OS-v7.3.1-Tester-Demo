"""Small, inspectable enforcement mechanisms for the Evidence Covenant."""
from __future__ import annotations

import hashlib
import json
import threading
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from enum import Enum, IntEnum
from pathlib import Path
from typing import Any


class ClaimClass(str, Enum):
    OBSERVED = "OBSERVED"
    INFERRED = "INFERRED"
    PROPOSED = "PROPOSED"
    UNVERIFIED = "UNVERIFIED"
    CONTRADICTED = "CONTRADICTED"
    VERIFIED = "VERIFIED"


class PrincipleState(str, Enum):
    DECLARED = "DECLARED"
    ENFORCED = "ENFORCED"
    VERIFIED = "VERIFIED"


class AuthorityLevel(IntEnum):
    OBSERVE = 0
    PROPOSE = 1
    MODIFY_SANDBOX = 2
    MODIFY_PROJECT = 3
    EXECUTE_GENERATED_CODE = 4
    AFFECT_EXTERNAL_SYSTEMS = 5


@dataclass(frozen=True)
class ConsentDecision:
    action: str
    level: int
    level_name: str
    allowed: bool
    explicit_approval: bool
    reason: str


class ConsentEngine:
    """Apply an autonomous allowance and a hard builder-defined ceiling."""

    def __init__(
        self,
        autonomous_through: AuthorityLevel = AuthorityLevel.PROPOSE,
        maximum_level: AuthorityLevel = AuthorityLevel.MODIFY_SANDBOX,
    ):
        if autonomous_through > maximum_level:
            raise ValueError("Autonomous authority cannot exceed the maximum level.")
        self.autonomous_through = autonomous_through
        self.maximum_level = maximum_level

    def decide(
        self,
        action: str,
        level: AuthorityLevel,
        *,
        explicit_approval: bool = False,
    ) -> ConsentDecision:
        if level > self.maximum_level:
            allowed = False
            reason = "Requested authority exceeds the builder-defined ceiling."
        elif level <= self.autonomous_through:
            allowed = True
            reason = "Action is inside the explicitly configured autonomous allowance."
        elif explicit_approval:
            allowed = True
            reason = "Builder approval was explicitly supplied for this bounded action."
        else:
            allowed = False
            reason = "Explicit approval is required; silence is not consent."
        return ConsentDecision(
            action=action,
            level=int(level),
            level_name=level.name,
            allowed=allowed,
            explicit_approval=explicit_approval,
            reason=reason,
        )


def canonical_json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


class HashLedger:
    """Append-only JSONL ledger with a replay-verifiable hash chain."""

    _lock = threading.Lock()

    def __init__(self, path: Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def entries(self) -> list[dict[str, Any]]:
        if not self.path.exists():
            return []
        result = []
        with self.path.open("r", encoding="utf-8") as handle:
            for line in handle:
                if line.strip():
                    result.append(json.loads(line))
        return result

    def append(self, event: str, detail: dict[str, Any]) -> dict[str, Any]:
        with self._lock:
            entries = self.entries()
            previous = entries[-1]["sha256"] if entries else "0" * 64
            body = {
                "time": datetime.now(timezone.utc).isoformat(),
                "event": event,
                "detail": detail,
                "prev_hash": previous,
            }
            record = {**body, "sha256": sha256_bytes(canonical_json(body).encode("utf-8"))}
            with self.path.open("a", encoding="utf-8") as handle:
                handle.write(canonical_json(record) + "\n")
            return record

    def verify(self) -> tuple[bool, str]:
        expected = "0" * 64
        try:
            entries = self.entries()
            for index, record in enumerate(entries, start=1):
                if record.get("prev_hash") != expected:
                    return False, f"Chain break at record {index}."
                claimed = record.get("sha256", "")
                body = {key: value for key, value in record.items() if key != "sha256"}
                actual = sha256_bytes(canonical_json(body).encode("utf-8"))
                if actual != claimed:
                    return False, f"Hash mismatch at record {index}."
                expected = claimed
        except (OSError, ValueError, TypeError) as exc:
            return False, f"Ledger unreadable: {exc}"
        return True, f"Chain intact ({len(entries)} records)."


def decision_dict(decision: ConsentDecision) -> dict[str, Any]:
    return asdict(decision)
