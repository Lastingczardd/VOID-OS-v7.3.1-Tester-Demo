"""Builder Orchestra: bounded specialist planning and execution.

The orchestra does not decide whether work is valuable. It only decomposes the
selected engineering experiment into explicit specialist assignments, runs the
available agents, and emits auditable lifecycle events. VIE and the Governor
remain authoritative.
"""
from __future__ import annotations

import hashlib
import json
import time
from dataclasses import asdict, dataclass, field
from typing import Any

from ..core.events import EventBus


@dataclass(frozen=True)
class SpecialistAssignment:
    role: str
    objective: str
    deliverable: str
    verification: str
    depends_on: tuple[str, ...] = ()
    required: bool = True


@dataclass(frozen=True)
class OrchestraPlan:
    cycle: int
    task: str
    fingerprint: str
    assignments: tuple[SpecialistAssignment, ...]
    execution_order: tuple[str, ...]
    created_at: int = field(default_factory=lambda: int(time.time()))


class BuilderOrchestra:
    """Plan and execute a small, explicit team of specialist agents.

    Safety properties:
    * only agents already registered in the local runtime may execute;
    * each role receives a bounded, role-specific mission;
    * plans are deterministic from task/winner/team inputs;
    * failures are returned as evidence instead of hidden;
    * no specialist can approve or promote its own output.
    """

    ROLE_HINTS = {
        "Architect": "Define the smallest coherent design and interfaces.",
        "Researcher": "Identify evidence gaps and assumptions. Do not fabricate sources.",
        "Coder": "Implement the selected bounded change with minimal surface area.",
        "Test Engineer": "Design high-value checks tied to the claim, not raw test count.",
        "Security Sentinel": "Inspect trust boundaries, path safety, secrets, and rollback risk.",
        "Performance Agent": "Measure the claimed performance dimension against a baseline.",
        "Documentation Agent": "Document operator-visible behavior and verified limitations.",
        "Debugger": "Localize the failure and propose the smallest reversible repair.",
        "Critic": "Challenge assumptions, proxy gaming, and unjustified complexity.",
        "Creator": "Offer a materially different but bounded implementation path.",
        "Product Builder": "Connect the change to a concrete operator outcome.",
    }

    def __init__(self, agents: Any, bus: EventBus, *, max_specialists: int = 6):
        self.agents = agents
        self.bus = bus
        self.max_specialists = max(1, min(12, int(max_specialists)))

    def plan(self, packet: dict[str, Any], cycle: int) -> OrchestraPlan:
        task = str(packet.get("task") or "Bounded engineering improvement.")
        winner = packet.get("winner") or {}
        team = [str(name) for name in packet.get("team") or []]
        available = set(getattr(self.agents, "agents", {}) or {})
        selected = [name for name in team if name in available][: self.max_specialists]
        if not selected:
            selected = sorted(available)[: self.max_specialists]

        assignments: list[SpecialistAssignment] = []
        for index, role in enumerate(selected):
            hint = self.ROLE_HINTS.get(role, "Contribute only evidence-grounded work within the selected experiment.")
            dependencies: tuple[str, ...] = ()
            if index and role in {"Coder", "Debugger"}:
                dependencies = tuple(r for r in selected[:index] if r in {"Architect", "Researcher"})
            if role in {"Test Engineer", "Security Sentinel", "Critic", "Documentation Agent"}:
                dependencies = tuple(r for r in selected[:index] if r in {"Coder", "Debugger", "Architect"})
            assignments.append(SpecialistAssignment(
                role=role,
                objective=f"{hint} Selected task: {task}",
                deliverable=self._deliverable_for(role),
                verification=self._verification_for(role, str(winner.get("verification") or "")),
                depends_on=dependencies,
                required=role in {"Architect", "Coder", "Test Engineer", "Critic"},
            ))

        material = json.dumps({"task": task, "winner": winner, "roles": selected}, sort_keys=True)
        fingerprint = hashlib.sha256(material.encode("utf-8")).hexdigest()[:24]
        plan = OrchestraPlan(
            cycle=int(cycle),
            task=task,
            fingerprint=fingerprint,
            assignments=tuple(assignments),
            execution_order=tuple(a.role for a in assignments),
        )
        self.bus.emit("OrchestraPlanned", self._plan_payload(plan), source="builder_orchestra", cycle=cycle)
        return plan

    def run(self, plan: OrchestraPlan, shared_context: str) -> dict[str, Any]:
        self.bus.emit("OrchestraStarted", {"fingerprint": plan.fingerprint, "roles": list(plan.execution_order)}, source="builder_orchestra", cycle=plan.cycle)
        results: list[dict[str, Any]] = []
        prior: dict[str, str] = {}
        for assignment in plan.assignments:
            prompt = self._prompt(plan, assignment, shared_context, prior)
            self.bus.emit("SpecialistStarted", {"fingerprint": plan.fingerprint, "role": assignment.role}, source="builder_orchestra", cycle=plan.cycle)
            try:
                raw = self.agents.team_run(prompt, names=[assignment.role])
                text = raw if isinstance(raw, str) else raw.get("synthesis", str(raw))
                text = str(text)[:16000]
                status = "COMPLETE" if text.strip() else "EMPTY"
                prior[assignment.role] = text
                row = {"role": assignment.role, "status": status, "output": text, "required": assignment.required}
            except Exception as exc:
                row = {"role": assignment.role, "status": "FAILED", "error": str(exc)[:1200], "required": assignment.required}
            results.append(row)
            self.bus.emit("SpecialistFinished", {k: v for k, v in row.items() if k != "output"} | {"fingerprint": plan.fingerprint}, source="builder_orchestra", cycle=plan.cycle)

        failed_required = [r["role"] for r in results if r.get("required") and r.get("status") != "COMPLETE"]
        synthesis = self._synthesize(plan, results)
        status = "COMPLETE" if not failed_required else "PARTIAL"
        report = {
            "status": status,
            "fingerprint": plan.fingerprint,
            "task": plan.task,
            "roles": list(plan.execution_order),
            "failed_required": failed_required,
            "results": results,
            "synthesis": synthesis,
        }
        self.bus.emit("OrchestraFinished", {k: v for k, v in report.items() if k not in {"results", "synthesis"}}, source="builder_orchestra", cycle=plan.cycle)
        return report

    @staticmethod
    def _deliverable_for(role: str) -> str:
        mapping = {
            "Architect": "A concise design contract, boundaries, and rollback plan.",
            "Researcher": "Assumptions, evidence needs, and unresolved questions.",
            "Coder": "A concrete patch proposal limited to the selected task.",
            "Test Engineer": "A small set of outcome-linked verification checks.",
            "Security Sentinel": "A threat and safety review with blocking findings separated.",
            "Performance Agent": "Before/after measurement design and acceptance threshold.",
            "Documentation Agent": "Operator-facing documentation for verified behavior only.",
            "Debugger": "Root-cause hypothesis, minimal repair, and regression check.",
            "Critic": "A red-team review of value, complexity, and proxy-gaming risk.",
        }
        return mapping.get(role, "A bounded specialist contribution with explicit evidence.")

    @staticmethod
    def _verification_for(role: str, winner_check: str) -> str:
        base = winner_check.strip() or "Use a deterministic pass/fail check tied to the engineering claim."
        if role == "Test Engineer":
            return base + " Reject test-count inflation and duplicate assertions."
        if role == "Critic":
            return "Attempt to falsify the claimed value and identify cheaper alternatives."
        return base

    @staticmethod
    def _plan_payload(plan: OrchestraPlan) -> dict[str, Any]:
        data = asdict(plan)
        data["assignments"] = [asdict(a) for a in plan.assignments]
        return data

    @staticmethod
    def _prompt(plan: OrchestraPlan, assignment: SpecialistAssignment, context: str, prior: dict[str, str]) -> str:
        dependencies = "\n\n".join(f"[{role}]\n{text[:5000]}" for role, text in prior.items() if role in assignment.depends_on)
        return (
            "VOID OS BUILDER ORCHESTRA SPECIALIST MISSION\n"
            f"CYCLE: {plan.cycle}\nTASK: {plan.task}\nROLE: {assignment.role}\n"
            f"OBJECTIVE: {assignment.objective}\nDELIVERABLE: {assignment.deliverable}\n"
            f"VERIFICATION: {assignment.verification}\n"
            "CONSTRAINTS: Do not approve the change. Do not inflate activity metrics. "
            "State uncertainty. Prefer the smallest reversible action.\n\n"
            f"DEPENDENCY OUTPUTS:\n{dependencies or 'None'}\n\n"
            f"PROJECT CONTEXT:\n{context[:14000]}"
        )

    @staticmethod
    def _synthesize(plan: OrchestraPlan, results: list[dict[str, Any]]) -> str:
        blocks = [f"# Builder Orchestra Report\n\nTask: {plan.task}\nFingerprint: {plan.fingerprint}"]
        for row in results:
            blocks.append(f"## {row['role']} [{row['status']}]\n{row.get('output') or row.get('error', '')}")
        blocks.append("## Authority Boundary\nThis report is builder evidence only. VIE and the Governor determine promotion.")
        return "\n\n".join(blocks)
