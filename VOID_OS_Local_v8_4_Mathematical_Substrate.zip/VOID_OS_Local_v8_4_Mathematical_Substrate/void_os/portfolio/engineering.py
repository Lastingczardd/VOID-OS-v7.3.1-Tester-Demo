"""Persistent portfolio of accepted, deferred, and rejected engineering bets."""
from __future__ import annotations

import json
from pathlib import Path

from ..core.events import Event


class EngineeringPortfolio:
    def __init__(self, state_root: Path):
        self.path = Path(state_root) / "engineering_portfolio.jsonl"
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def consume(self, event: Event) -> None:
        if event.name != "GovernorDecision":
            return
        p = event.payload
        row = {
            "cycle": event.cycle,
            "decision": p.get("decision"),
            "accepted": bool(p.get("accepted")),
            "vis": p.get("vis"),
            "predicted_value": p.get("predictive", {}).get("expected_long_term_value"),
            "regression_probability": p.get("predictive", {}).get("regression_probability"),
            "maintenance_pressure": p.get("predictive", {}).get("maintenance_pressure"),
            "fingerprint": p.get("fingerprint"),
            "created_at": event.created_at,
        }
        with self.path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n")
