"""Value Integrity Engine for adversarially robust autonomous engineering.

The builder proposes and applies changes. This module independently captures a
baseline, verifies the result with fixed local checks, prices complexity, rejects
proxy gaming, remembers regressions, and emits an auditable promotion decision.
"""
from __future__ import annotations

import ast
import hashlib
import json
import math
import subprocess
import sys
import time
from dataclasses import asdict, dataclass
from pathlib import Path

from .predictive_value import PredictiveValueModel

_IGNORED = {".git", "__pycache__", "outputs", "backups", "autopilot", ".pytest_cache"}
_SOURCE_SUFFIXES = {".py", ".js", ".ts", ".html", ".css", ".json", ".toml", ".yaml", ".yml"}


@dataclass(frozen=True)
class EngineeringClaim:
    problem: str
    hypothesis: str
    expected_effect: str
    affected_users: str
    verification: str


class ValueIntegrityEngine:
    """Independent verifier and governor for one autonomous project cycle."""

    def __init__(self, cfg: dict, project_root: Path, state_root: Path):
        self.cfg = cfg
        self.project_root = Path(project_root).resolve()
        self.state_root = Path(state_root).resolve()
        self.state_root.mkdir(parents=True, exist_ok=True)
        self.ledger = self.state_root / "value_integrity_ledger.jsonl"
        self.regressions = self.state_root / "regression_memory.jsonl"
        self.novelty = self.state_root / "novelty_index.json"
        self.audit_path = self.state_root / "reality_audits.jsonl"
        self.vcfg = cfg.get("value_integrity", {})
        self.predictor = PredictiveValueModel(cfg)

    def make_claim(self, packet: dict) -> EngineeringClaim:
        op = packet.get("opportunity", {})
        winner = packet.get("winner", {})
        task = str(packet.get("task") or "Improve verified project behavior.")
        return EngineeringClaim(
            problem=task[:600],
            hypothesis=str(winner.get("approach") or "A bounded change will improve the stated outcome.")[:900],
            expected_effect=str(winner.get("verification") or "A fixed validation check improves without regression.")[:600],
            affected_users=str(op.get("evidence") or "Operators of the active local project")[:500],
            verification=str(winner.get("verification") or "Compile, run tests, compare baseline, and inspect complexity.")[:600],
        )

    def begin(self, cycle: int, claim: EngineeringClaim) -> dict:
        baseline = self.snapshot()
        record = {
            "cycle": int(cycle),
            "started_at": int(time.time()),
            "claim": asdict(claim),
            "baseline": baseline,
            "fingerprint": self._fingerprint(claim),
        }
        self._append("baseline_captured", record)
        return record

    def evaluate(self, run: dict, implementation: dict | None = None) -> dict:
        implementation = implementation or {}
        after = self.snapshot()
        before = run["baseline"]
        validation = self._run_fixed_validation()
        hidden = self._run_test_group("evaluation/hidden")
        historical = self._run_test_group("evaluation/historical")
        canary = self._run_test_group("evaluation/canary")
        complexity = self._complexity_delta(before, after)
        novelty = self._novelty(run["fingerprint"])
        applied = implementation.get("status") == "APPLIED"

        outcome_gain = self._outcome_gain(before, after, validation, hidden, historical, canary, applied)
        confidence = self._confidence(validation, hidden, historical, canary)
        durability = self._durability(hidden, historical, canary)
        risk = self._risk(complexity, validation, hidden, historical, canary)
        cost = max(1.0, float(complexity["changed_files"]) + complexity["added_kib"] * 0.4)
        denominator = 1.0 + complexity["cost"] + risk + cost
        vis = round((outcome_gain * confidence * durability) / denominator, 4)

        gates = {
            "claim_specific": len(run["claim"]["problem"].strip()) >= 12,
            "baseline_captured": bool(before.get("tree_hash")),
            "implementation_applied": applied,
            "fixed_validation": validation["passed"],
            "hidden_evaluation": hidden["passed"],
            "historical_regressions": historical["passed"],
            "canary_workloads": canary["passed"],
            "complexity_budget": complexity["cost"] <= float(self.vcfg.get("max_complexity_cost", 18.0)),
            "novel_enough": novelty["novel"],
            "verified_outcome": outcome_gain >= float(self.vcfg.get("min_outcome_gain", 1.0)),
            "value_integrity_score": vis >= float(self.vcfg.get("min_vis", 0.15)),
            "anti_test_padding": not complexity["test_padding_suspected"],
        }
        hard = ["claim_specific", "baseline_captured", "implementation_applied", "fixed_validation",
                "hidden_evaluation", "historical_regressions", "canary_workloads", "complexity_budget",
                "verified_outcome", "anti_test_padding"]
        accepted = all(gates[k] for k in hard)
        decision = "ACCEPT" if accepted else ("RETRY" if applied and validation["passed"] else "REJECT")
        reasons = [name for name, passed in gates.items() if not passed]

        report = {
            "cycle": run["cycle"], "recorded_at": int(time.time()), "decision": decision,
            "accepted": accepted, "vis": vis, "outcome_gain": round(outcome_gain, 3),
            "confidence": round(confidence, 3), "durability": round(durability, 3),
            "risk": round(risk, 3), "cost": round(cost, 3), "complexity": complexity,
            "novelty": novelty, "gates": gates, "failed_gates": reasons,
            "baseline": before, "after": after, "validation": validation,
            "hidden": hidden, "historical": historical, "canary": canary,
            "implementation": implementation,
        }
        report["fingerprint"] = run.get("fingerprint")
        report["predictive"] = self.predictor.forecast(report)
        self._append("promotion_decision", report)
        if not accepted:
            self._append_regression(report)
        else:
            self._remember_novelty(run["fingerprint"], report)
        return report

    def reality_audit(self, cycle: int) -> dict | None:
        every = max(1, int(self.vcfg.get("reality_audit_every_cycles", 5)))
        if cycle % every:
            return None
        records = []
        try:
            for line in self.ledger.read_text(encoding="utf-8").splitlines():
                row = json.loads(line)
                if row.get("event") == "promotion_decision":
                    records.append(row["payload"])
        except Exception:
            pass
        recent = records[-every * 2:]
        accepted = [r for r in recent if r.get("accepted")]
        audit = {
            "cycle": cycle, "recorded_at": int(time.time()), "window": len(recent),
            "acceptance_rate": round(len(accepted) / max(1, len(recent)), 3),
            "median_vis": self._median([float(r.get("vis", 0)) for r in recent]),
            "mean_complexity_cost": round(sum(float(r.get("complexity", {}).get("cost", 0)) for r in recent) / max(1, len(recent)), 3),
            "test_padding_flags": sum(bool(r.get("complexity", {}).get("test_padding_suspected")) for r in recent),
            "reverted_or_rejected": sum(not bool(r.get("accepted")) for r in recent),
        }
        self._write_jsonl(self.audit_path, audit)
        self._append("reality_audit", audit)
        return audit

    def snapshot(self) -> dict:
        files = []
        source_lines = test_lines = test_files = dependencies = 0
        digest = hashlib.sha256()
        for path in sorted(self.project_root.rglob("*")):
            if not path.is_file() or path.is_symlink() or any(part in _IGNORED for part in path.parts):
                continue
            rel = path.relative_to(self.project_root).as_posix()
            try:
                data = path.read_bytes()
            except OSError:
                continue
            digest.update(rel.encode()); digest.update(hashlib.sha256(data).digest())
            files.append({"path": rel, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()})
            if path.suffix.lower() in _SOURCE_SUFFIXES:
                text = data.decode("utf-8", errors="replace")
                lines = sum(1 for line in text.splitlines() if line.strip())
                is_test = rel.startswith("tests/") or "/tests/" in rel or path.name.startswith("test_")
                if is_test:
                    test_lines += lines; test_files += 1
                else:
                    source_lines += lines
                if path.suffix.lower() == ".py":
                    dependencies += len(self._imports(text))
        return {
            "tree_hash": digest.hexdigest(), "file_count": len(files),
            "bytes": sum(x["bytes"] for x in files), "source_lines": source_lines,
            "test_lines": test_lines, "test_files": test_files, "dependency_imports": dependencies,
            "files": files,
        }

    def _run_fixed_validation(self) -> dict:
        commands = [[sys.executable, "-m", "compileall", "-q", str(self.project_root)]]
        tests = self.project_root / "tests"
        if tests.is_dir():
            commands.append([sys.executable, "-m", "unittest", "discover", "-s", str(tests), "-p", "test*.py"])
        return self._run_commands(commands)

    def _run_test_group(self, rel: str) -> dict:
        path = self.project_root / rel
        if not path.is_dir():
            return {"passed": True, "status": "NOT_CONFIGURED", "output": "No evaluator-owned suite configured."}
        return self._run_commands([[sys.executable, "-m", "unittest", "discover", "-s", str(path), "-p", "test*.py"]])

    def _run_commands(self, commands: list[list[str]]) -> dict:
        output = []
        for cmd in commands:
            try:
                proc = subprocess.run(cmd, cwd=str(self.project_root), capture_output=True, text=True,
                                      timeout=int(self.vcfg.get("validation_timeout_seconds", 90)), shell=False)
                output.append((proc.stdout + proc.stderr).strip())
                if proc.returncode:
                    return {"passed": False, "status": "FAILED", "output": "\n".join(output)[-8000:]}
            except Exception as exc:
                return {"passed": False, "status": "ERROR", "output": str(exc)}
        return {"passed": True, "status": "PASSED", "output": "\n".join(output)[-8000:] or "Checks passed."}

    def _complexity_delta(self, before: dict, after: dict) -> dict:
        b = {x["path"]: x for x in before["files"]}; a = {x["path"]: x for x in after["files"]}
        changed = sum(1 for p in set(a) | set(b) if a.get(p, {}).get("sha256") != b.get(p, {}).get("sha256"))
        added_bytes = after["bytes"] - before["bytes"]
        src_delta = after["source_lines"] - before["source_lines"]
        test_delta = after["test_lines"] - before["test_lines"]
        dep_delta = after["dependency_imports"] - before["dependency_imports"]
        ratio_before = before["test_lines"] / max(1, before["source_lines"])
        ratio_after = after["test_lines"] / max(1, after["source_lines"])
        padding = test_delta > max(120, abs(src_delta) * 5) and ratio_after > ratio_before * 1.75
        cost = max(0, changed - 1) * 1.5 + max(0, src_delta) / 120 + max(0, dep_delta) * 2.5 + max(0, added_bytes) / 16384
        if padding: cost += 12
        return {"changed_files": changed, "added_kib": round(added_bytes / 1024, 3),
                "source_line_delta": src_delta, "test_line_delta": test_delta,
                "dependency_delta": dep_delta, "test_padding_suspected": padding,
                "cost": round(cost, 3)}

    @staticmethod
    def _outcome_gain(before, after, validation, hidden, historical, canary, applied):
        if not applied or not validation["passed"]:
            return 0.0
        gain = 1.0
        if hidden["status"] == "PASSED": gain += 2.0
        if historical["status"] == "PASSED": gain += 2.0
        if canary["status"] == "PASSED": gain += 2.0
        if after["source_lines"] < before["source_lines"]: gain += min(2.0, (before["source_lines"] - after["source_lines"]) / 100)
        # Added tests never create outcome value by themselves. They only raise confidence.
        return gain

    @staticmethod
    def _confidence(validation, hidden, historical, canary):
        score = 0.45 if validation["passed"] else 0.0
        configured = [x for x in (hidden, historical, canary) if x["status"] != "NOT_CONFIGURED"]
        score += 0.45 * (sum(x["passed"] for x in configured) / max(1, len(configured))) if configured else 0.15
        return min(1.0, score)

    @staticmethod
    def _durability(hidden, historical, canary):
        configured = [x for x in (hidden, historical, canary) if x["status"] != "NOT_CONFIGURED"]
        return 0.65 if not configured else max(0.0, sum(x["passed"] for x in configured) / len(configured))

    @staticmethod
    def _risk(complexity, validation, hidden, historical, canary):
        risk = complexity["changed_files"] * 0.35 + max(0, complexity["dependency_delta"]) * 1.5
        risk += 0 if validation["passed"] else 10
        risk += sum(4 for x in (hidden, historical, canary) if not x["passed"])
        return risk

    def _novelty(self, fingerprint: str) -> dict:
        try: idx = json.loads(self.novelty.read_text(encoding="utf-8"))
        except Exception: idx = {}
        return {"fingerprint": fingerprint, "novel": fingerprint not in idx, "prior": idx.get(fingerprint)}

    def _remember_novelty(self, fingerprint: str, report: dict) -> None:
        try: idx = json.loads(self.novelty.read_text(encoding="utf-8"))
        except Exception: idx = {}
        idx[fingerprint] = {"cycle": report["cycle"], "vis": report["vis"], "recorded_at": report["recorded_at"]}
        self.novelty.write_text(json.dumps(idx, indent=2), encoding="utf-8")

    @staticmethod
    def _fingerprint(claim: EngineeringClaim) -> str:
        normalized = " ".join((claim.problem + " " + claim.hypothesis).lower().split())
        return hashlib.sha256(normalized.encode()).hexdigest()[:24]

    @staticmethod
    def _imports(text: str) -> set[str]:
        try: tree = ast.parse(text)
        except SyntaxError: return set()
        names = set()
        for node in ast.walk(tree):
            if isinstance(node, ast.Import): names.update(alias.name.split(".")[0] for alias in node.names)
            elif isinstance(node, ast.ImportFrom) and node.module: names.add(node.module.split(".")[0])
        return names

    def _append(self, event: str, payload: dict) -> None:
        self._write_jsonl(self.ledger, {"event": event, "time": int(time.time()), "payload": payload})

    def _append_regression(self, report: dict) -> None:
        self._write_jsonl(self.regressions, {"cycle": report["cycle"], "failed_gates": report["failed_gates"],
                                             "tree_hash": report["after"]["tree_hash"], "time": int(time.time())})

    @staticmethod
    def _write_jsonl(path: Path, value: dict) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8") as handle: handle.write(json.dumps(value, ensure_ascii=False) + "\n")

    @staticmethod
    def _median(values: list[float]) -> float:
        if not values: return 0.0
        values = sorted(values); n = len(values); mid = n // 2
        return round(values[mid] if n % 2 else (values[mid-1] + values[mid]) / 2, 4)
