"""Conservative long-horizon projection layered on verified VIE evidence.

This module deliberately exposes only bounded estimates, never guarantees. It
uses already-verified evidence and cannot independently approve a change.
"""
from __future__ import annotations


class PredictiveValueModel:
    def __init__(self, cfg: dict):
        self.cfg = cfg.get("predictive_value", {})

    def forecast(self, report: dict) -> dict:
        complexity = float(report.get("complexity", {}).get("cost", 0.0))
        risk = float(report.get("risk", 0.0))
        confidence = float(report.get("confidence", 0.0))
        durability = float(report.get("durability", 0.0))
        outcome = float(report.get("outcome_gain", 0.0))
        accepted = bool(report.get("accepted"))

        regression_probability = self._clamp((risk * 0.055) + (1.0 - confidence) * 0.45 + complexity * 0.012, 0.02, 0.98)
        maintenance_pressure = self._clamp(complexity / max(1.0, float(self.cfg.get("complexity_reference", 18.0))), 0.0, 1.0)
        adaptability = self._clamp(durability * (1.0 - maintenance_pressure * 0.45), 0.0, 1.0)
        leverage = self._clamp((outcome / max(1.0, complexity + 1.0)) * confidence, 0.0, 1.0)
        expected_long_term_value = round(outcome * confidence * adaptability * (1.0 - regression_probability), 4)

        if not accepted:
            expected_long_term_value = 0.0

        horizon = "short"
        if expected_long_term_value >= 1.5 and regression_probability < 0.25:
            horizon = "long"
        elif expected_long_term_value >= 0.5:
            horizon = "medium"

        return {
            "expected_long_term_value": expected_long_term_value,
            "regression_probability": round(regression_probability, 4),
            "maintenance_pressure": round(maintenance_pressure, 4),
            "adaptability": round(adaptability, 4),
            "future_leverage": round(leverage, 4),
            "value_horizon": horizon,
            "confidence_note": "Bounded estimate derived from verified local evidence; not a guarantee.",
        }

    @staticmethod
    def _clamp(value: float, low: float, high: float) -> float:
        return max(low, min(high, value))
