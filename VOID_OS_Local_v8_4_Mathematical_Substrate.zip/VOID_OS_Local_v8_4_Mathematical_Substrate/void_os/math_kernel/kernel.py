from __future__ import annotations

from dataclasses import asdict
from pathlib import Path

from .ledger import EvidenceLedger
from .math_substrate import (
    deepen, fold, digital_root, triangle_reduced, reduce_text
)
from .models import Decision, TransitionRequest, VoidState
from .policy import ContinuousWill


class NullKernel:
    def __init__(self, database: str | Path = "data/void_os.db") -> None:
        self.ledger = EvidenceLedger(database)
        stored = self.ledger.load_state()
        self.state = VoidState.from_json(stored) if stored else VoidState()
        self.policy = ContinuousWill()

    def boot(self) -> VoidState:
        self.ledger.append("BOOT", {
            "version": "8.4.0",
            "operator": "@LastingCzardd",
            "state": asdict(self.state),
        })
        self._persist()
        return self.state

    def apply(self, request: TransitionRequest) -> tuple[Decision, VoidState]:
        decision = self.policy.decide(self.state, request)
        before = asdict(self.state)

        if not decision.allowed:
            self.ledger.append("VETO", {
                "request": asdict(request),
                "decision": asdict(decision),
                "state": before,
            })
            return decision, self.state

        op = decision.operation
        value = request.value

        if op == "polarize":
            sign = int(value if value is not None else 1)
            self.state.polarity = 1 if sign >= 0 else -1
            self.state.z = float(self.state.polarity)
            self.state.mode = "POLARIZED"

        elif op == "deepen":
            depth = int(value if value is not None else 1)
            self.state.z = deepen(self.state.z, depth)
            self.state.deepen_depth += depth
            self.state.mode = "DEEPENING"

        elif op == "fold":
            depth = int(value if value is not None else 1)
            self.state.z = fold(self.state.z, depth)
            self.state.fold_depth += depth
            self.state.mode = "FOLDING"

        elif op == "reduce":
            if isinstance(value, str):
                raw, reduced = reduce_text(value)
                self.state.metadata["last_reduction"] = {
                    "input": value, "raw": raw, "reduced": reduced
                }
            else:
                reduced = digital_root(int(value or 0))
            self.state.reduced_signature = reduced
            self.state.mode = "REDUCED"

        elif op == "triangle":
            source = int(value if value is not None else self.state.reduced_signature)
            self.state.reduced_signature = triangle_reduced(source)
            self.state.mode = "TRIANGLE"

        elif op == "normalize":
            previous_z = self.state.z
            self.state.z = 0.0
            self.state.polarity = 0
            self.state.mode = "NULL"
            self.state.metadata["last_normalized_value"] = previous_z

        elif op == "observe":
            self.state.metadata["last_observation"] = request.reason
            self.state.mode = "WITNESS"

        self.state.cycle += 1
        after = asdict(self.state)
        self.ledger.append("TRANSITION", {
            "request": asdict(request),
            "decision": asdict(decision),
            "before": before,
            "after": after,
        })
        self._persist()
        return decision, self.state

    def _persist(self) -> None:
        self.ledger.save_state(self.state.to_json())
