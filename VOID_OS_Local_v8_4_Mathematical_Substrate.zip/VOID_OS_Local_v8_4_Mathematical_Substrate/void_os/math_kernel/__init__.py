"""VOID OS Φ∞ mathematical substrate subsystem."""

__version__ = "8.4.0"

from .kernel import NullKernel
from .models import Decision, TransitionRequest, VoidState

__all__ = ["NullKernel", "Decision", "TransitionRequest", "VoidState"]
