from __future__ import annotations

import argparse
import json
import shlex
from dataclasses import asdict

from .kernel import NullKernel
from .math_substrate import reduce_text, verify_fold_invariant
from .models import TransitionRequest


BANNER = r"""
VOID OS Φ∞ v8.4
NULL KERNEL / EVIDENCE-BOUND BUILD
Operator: @LastingCzardd
"""


def print_state(kernel: NullKernel) -> None:
    print(json.dumps(asdict(kernel.state), indent=2, sort_keys=True))


def shell() -> None:
    kernel = NullKernel()
    kernel.boot()
    print(BANNER)
    print("Commands: state, polarize [1|-1], deepen [n], fold [n],")
    print("          reduce <text|integer>, triangle [n], normalize,")
    print("          observe <statement>, history, verify, invariant <x> <n>, quit")
    while True:
        try:
            line = input("LastingCzardd@void ~ Φ∞ $ ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            break
        if not line:
            continue
        parts = shlex.split(line)
        command = parts[0].lower()
        args = parts[1:]

        if command in {"quit", "exit"}:
            break
        if command == "state":
            print_state(kernel)
            continue
        if command == "history":
            for event in reversed(kernel.ledger.recent(10)):
                print(f"{event['id']:04d} {event['created_at']} {event['event_type']} {event['event_hash'][:12]}")
            continue
        if command == "verify":
            valid, errors = kernel.ledger.verify()
            print("LEDGER VERIFIED" if valid else "\n".join(errors))
            continue
        if command == "invariant":
            value = float(args[0])
            depth = int(args[1] if len(args) > 1 else 1)
            print(verify_fold_invariant(value, depth))
            continue

        value = None
        reason = ""
        if command in {"polarize", "deepen", "fold", "triangle"}:
            value = int(args[0]) if args else 1
        elif command == "reduce":
            raw = " ".join(args)
            try:
                value = int(raw)
            except ValueError:
                value = raw
        elif command == "observe":
            reason = " ".join(args)

        decision, state = kernel.apply(
            TransitionRequest(operation=command, value=value, reason=reason)
        )
        print(f"{'ACCEPT' if decision.allowed else 'VETO'}: {decision.reason}")
        print_state(kernel)


def main() -> None:
    parser = argparse.ArgumentParser(prog="void-os")
    parser.add_argument("command", nargs="?", default="shell",
                        choices=["shell", "boot", "state", "verify"])
    args = parser.parse_args()
    kernel = NullKernel()

    if args.command == "shell":
        shell()
    elif args.command == "boot":
        kernel.boot()
        print(BANNER)
        print_state(kernel)
    elif args.command == "state":
        print_state(kernel)
    elif args.command == "verify":
        valid, errors = kernel.ledger.verify()
        print("LEDGER VERIFIED" if valid else "\n".join(errors))


if __name__ == "__main__":
    main()
