from __future__ import annotations

from .models import Decision, TransitionRequest, VoidState


SUPPORTED_OPERATIONS = {
    "polarize", "deepen", "fold", "reduce", "triangle", "normalize", "observe"
}


class RealityVeto:
    """Reject invalid or unsupported transitions before they touch the kernel."""

    def evaluate(self, state: VoidState, request: TransitionRequest) -> Decision:
        op = request.operation.lower().strip()

        if op not in SUPPORTED_OPERATIONS:
            return Decision(False, op, "Unknown operation", 0.0, ("known_operation",))

        if op in {"deepen", "fold"}:
            try:
                depth = int(request.value if request.value is not None else 1)
            except (TypeError, ValueError):
                return Decision(False, op, "Depth must be an integer", 0.0, ("valid_depth",))
            if depth < 0 or depth > 6:
                return Decision(
                    False, op, "Depth outside safe prototype boundary 0..6",
                    0.0, ("bounded_recursion",)
                )

        if op == "observe" and not request.reason.strip():
            return Decision(
                False, op, "Observations require a non-empty statement",
                0.0, ("evidence_required",)
            )

        evidence_score = min(len(request.evidence) * 0.15, 0.45)
        reason_score = 0.25 if request.reason.strip() else 0.0
        base_score = 0.30
        score = min(base_score + evidence_score + reason_score, 1.0)
        return Decision(True, op, "Transition accepted", score)


class ContinuousWill:
    """Policy layer. Chooses only among operations that pass the Reality Veto."""

    def __init__(self, veto: RealityVeto | None = None) -> None:
        self.veto = veto or RealityVeto()

    def decide(self, state: VoidState, request: TransitionRequest) -> Decision:
        return self.veto.evaluate(state, request)
