from __future__ import annotations

import math
import re
from dataclasses import dataclass


def digital_root(value: int) -> int:
    """Return the decimal digital root. Zero maps to zero."""
    if not isinstance(value, int):
        raise TypeError("digital_root expects an integer")
    value = abs(value)
    return 0 if value == 0 else 1 + ((value - 1) % 9)


def polarity(value: float = 1.0) -> tuple[float, float]:
    magnitude = abs(float(value))
    return (-magnitude, magnitude)


def deepen(value: float, depth: int = 1) -> float:
    if depth < 0:
        raise ValueError("depth must be non-negative")
    result = float(value)
    for _ in range(depth):
        result = result ** 3
    return result


def real_cube_root(value: float) -> float:
    return math.copysign(abs(value) ** (1.0 / 3.0), value)


def fold(value: float, depth: int = 1) -> float:
    if depth < 0:
        raise ValueError("depth must be non-negative")
    result = float(value)
    for _ in range(depth):
        result = real_cube_root(result)
    return result


def tetractys(order: int = 4) -> int:
    if order < 0:
        raise ValueError("order must be non-negative")
    return order * (order + 1) // 2


def triangle(value: int) -> int:
    if value < 0:
        raise ValueError("triangle expects a non-negative integer")
    return value * (value + 1) // 2


def triangle_reduced(value: int) -> int:
    return digital_root(triangle(value))


def letter_value(letter: str) -> int:
    if len(letter) != 1 or not letter.isalpha():
        raise ValueError("letter_value expects one alphabetic character")
    position = ord(letter.upper()) - ord("A") + 1
    return 1 + ((position - 1) % 9)


def reduce_text(text: str) -> tuple[int, int]:
    letters = re.findall(r"[A-Za-z]", text)
    raw = sum(letter_value(ch) for ch in letters)
    return raw, digital_root(raw)


@dataclass(frozen=True)
class InvariantReport:
    input_value: float
    depth: int
    deepened: float
    restored: float
    absolute_error: float
    passed: bool


def verify_fold_invariant(value: float, depth: int = 1, tolerance: float = 1e-9) -> InvariantReport:
    deepened = deepen(value, depth)
    restored = fold(deepened, depth)
    error = abs(restored - float(value))
    return InvariantReport(
        input_value=float(value),
        depth=depth,
        deepened=deepened,
        restored=restored,
        absolute_error=error,
        passed=error <= tolerance,
    )
