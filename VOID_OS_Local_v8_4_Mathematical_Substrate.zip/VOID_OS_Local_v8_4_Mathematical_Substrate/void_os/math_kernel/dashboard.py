from __future__ import annotations

import json
import tkinter as tk
from dataclasses import asdict
from tkinter import ttk, messagebox

from .kernel import NullKernel
from .models import TransitionRequest


class Dashboard(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title("VOID OS Φ∞ v8.4")
        self.geometry("880x620")
        self.kernel = NullKernel()
        self.kernel.boot()

        header = ttk.Label(self, text="VOID OS Φ∞ — NULL KERNEL", font=("Segoe UI", 18, "bold"))
        header.pack(pady=(16, 4))
        ttk.Label(self, text="Return does not equal erasure.").pack()

        controls = ttk.Frame(self)
        controls.pack(fill="x", padx=16, pady=12)

        self.value = ttk.Entry(controls)
        self.value.insert(0, "1")
        self.value.pack(side="left", fill="x", expand=True, padx=(0, 8))

        for label, op in [
            ("+1", "polarize"), ("Deepen", "deepen"), ("Fold", "fold"),
            ("Reduce", "reduce"), ("Triangle", "triangle"), ("Normalize", "normalize")
        ]:
            ttk.Button(controls, text=label, command=lambda o=op: self.apply(o)).pack(side="left", padx=3)

        observe_frame = ttk.Frame(self)
        observe_frame.pack(fill="x", padx=16)
        self.observation = ttk.Entry(observe_frame)
        self.observation.pack(side="left", fill="x", expand=True, padx=(0, 8))
        ttk.Button(observe_frame, text="Witness", command=lambda: self.apply("observe")).pack(side="left")

        self.output = tk.Text(self, wrap="word", font=("Consolas", 10))
        self.output.pack(fill="both", expand=True, padx=16, pady=12)

        footer = ttk.Frame(self)
        footer.pack(fill="x", padx=16, pady=(0, 12))
        ttk.Button(footer, text="Refresh State", command=self.refresh).pack(side="left")
        ttk.Button(footer, text="Verify Ledger", command=self.verify).pack(side="left", padx=8)

        self.refresh()

    def apply(self, operation: str) -> None:
        raw = self.value.get().strip()
        value: object = raw
        reason = ""
        if operation in {"polarize", "deepen", "fold", "triangle"}:
            try:
                value = int(raw or "1")
            except ValueError:
                messagebox.showerror("Invalid value", "This operation requires an integer.")
                return
        elif operation == "normalize":
            value = None
        elif operation == "observe":
            value = None
            reason = self.observation.get().strip()

        decision, _ = self.kernel.apply(
            TransitionRequest(operation=operation, value=value, reason=reason)
        )
        if not decision.allowed:
            messagebox.showwarning("Reality Veto", decision.reason)
        self.refresh()

    def refresh(self) -> None:
        payload = {
            "state": asdict(self.kernel.state),
            "recent_events": self.kernel.ledger.recent(8),
        }
        self.output.delete("1.0", "end")
        self.output.insert("1.0", json.dumps(payload, indent=2))

    def verify(self) -> None:
        valid, errors = self.kernel.ledger.verify()
        messagebox.showinfo("Ledger", "VERIFIED" if valid else "\n".join(errors))


def main() -> None:
    Dashboard().mainloop()


if __name__ == "__main__":
    main()
