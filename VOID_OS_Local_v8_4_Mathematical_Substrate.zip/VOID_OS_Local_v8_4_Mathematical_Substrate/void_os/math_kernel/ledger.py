from __future__ import annotations

import hashlib
import json
import sqlite3
from pathlib import Path
from typing import Any

from .models import utc_now


GENESIS_HASH = "0" * 64


class EvidenceLedger:
    """Append-only event ledger with a simple SHA-256 hash chain."""

    def __init__(self, path: str | Path = "data/void_os.db") -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._initialize()

    def connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self.path)
        connection.row_factory = sqlite3.Row
        return connection

    def _initialize(self) -> None:
        with self.connect() as con:
            con.execute("""
                CREATE TABLE IF NOT EXISTS events (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    created_at TEXT NOT NULL,
                    event_type TEXT NOT NULL,
                    payload TEXT NOT NULL,
                    previous_hash TEXT NOT NULL,
                    event_hash TEXT NOT NULL UNIQUE
                )
            """)
            con.execute("""
                CREATE TABLE IF NOT EXISTS state (
                    singleton INTEGER PRIMARY KEY CHECK (singleton = 1),
                    payload TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                )
            """)

    @staticmethod
    def _hash(created_at: str, event_type: str, payload: str, previous_hash: str) -> str:
        material = "|".join((created_at, event_type, payload, previous_hash))
        return hashlib.sha256(material.encode("utf-8")).hexdigest()

    def append(self, event_type: str, payload: dict[str, Any]) -> str:
        payload_text = json.dumps(payload, sort_keys=True, separators=(",", ":"))
        created_at = utc_now()
        with self.connect() as con:
            row = con.execute(
                "SELECT event_hash FROM events ORDER BY id DESC LIMIT 1"
            ).fetchone()
            previous = row["event_hash"] if row else GENESIS_HASH
            event_hash = self._hash(created_at, event_type, payload_text, previous)
            con.execute(
                """INSERT INTO events
                   (created_at, event_type, payload, previous_hash, event_hash)
                   VALUES (?, ?, ?, ?, ?)""",
                (created_at, event_type, payload_text, previous, event_hash),
            )
        return event_hash

    def save_state(self, payload: str) -> None:
        with self.connect() as con:
            con.execute(
                """INSERT INTO state(singleton, payload, updated_at)
                   VALUES(1, ?, ?)
                   ON CONFLICT(singleton)
                   DO UPDATE SET payload=excluded.payload, updated_at=excluded.updated_at""",
                (payload, utc_now()),
            )

    def load_state(self) -> str | None:
        with self.connect() as con:
            row = con.execute("SELECT payload FROM state WHERE singleton=1").fetchone()
            return row["payload"] if row else None

    def recent(self, limit: int = 20) -> list[dict[str, Any]]:
        with self.connect() as con:
            rows = con.execute(
                "SELECT * FROM events ORDER BY id DESC LIMIT ?", (limit,)
            ).fetchall()
        return [dict(row) for row in rows]

    def verify(self) -> tuple[bool, list[str]]:
        errors: list[str] = []
        previous = GENESIS_HASH
        with self.connect() as con:
            rows = con.execute("SELECT * FROM events ORDER BY id ASC").fetchall()
        for row in rows:
            if row["previous_hash"] != previous:
                errors.append(f"Event {row['id']}: previous hash mismatch")
            calculated = self._hash(
                row["created_at"], row["event_type"], row["payload"], row["previous_hash"]
            )
            if calculated != row["event_hash"]:
                errors.append(f"Event {row['id']}: event hash mismatch")
            previous = row["event_hash"]
        return (not errors, errors)
