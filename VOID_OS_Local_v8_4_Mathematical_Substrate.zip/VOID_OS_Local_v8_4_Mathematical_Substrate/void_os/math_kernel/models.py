from __future__ import annotations

from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from typing import Any
import json


@dataclass
class VoidState:
    z: float = 0.0
    polarity: int = 0
    deepen_depth: int = 0
    fold_depth: int = 0
    reduced_signature: int = 0
    cycle: int = 0
    mode: str = "NULL"
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_json(self) -> str:
        return json.dumps(asdict(self), sort_keys=True)

    @classmethod
    def from_json(cls, payload: str) -> "VoidState":
        return cls(**json.loads(payload))


@dataclass(frozen=True)
class TransitionRequest:
    operation: str
    value: float | int | str | None = None
    reason: str = ""
    evidence: tuple[str, ...] = ()
    operator: str = "@LastingCzardd"


@dataclass(frozen=True)
class Decision:
    allowed: bool
    operation: str
    reason: str
    score: float
    constraints: tuple[str, ...] = ()


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()
