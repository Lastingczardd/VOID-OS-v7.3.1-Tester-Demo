"""Small, deterministic event bus with an append-only local audit log."""
from __future__ import annotations

import json
import threading
import time
import uuid
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Callable


@dataclass(frozen=True)
class Event:
    name: str
    payload: dict[str, Any]
    source: str = "void_os"
    cycle: int | None = None
    event_id: str = field(default_factory=lambda: uuid.uuid4().hex)
    created_at: int = field(default_factory=lambda: int(time.time()))
    schema_version: int = 1


class EventRejected(PermissionError):
    """Raised when a protected event fails its authority policy."""


class EventBus:
    """In-process pub/sub plus durable JSONL recording.

    Subscriber failures are isolated and recorded as diagnostic events instead
    of breaking the engineering cycle.
    """

    def __init__(self, state_root: Path):
        self.state_root = Path(state_root)
        self.state_root.mkdir(parents=True, exist_ok=True)
        self.log_path = self.state_root / "events.jsonl"
        self._subscribers: dict[str, list[Callable[[Event], None]]] = {}
        self._protectors: dict[str, Callable[[Event], tuple[bool, str]]] = {}
        self._lock = threading.RLock()

    def subscribe(self, event_name: str, handler: Callable[[Event], None]) -> None:
        with self._lock:
            self._subscribers.setdefault(event_name, []).append(handler)

    def protect(
        self,
        event_name: str,
        validator: Callable[[Event], tuple[bool, str]],
    ) -> None:
        """Install a pre-publication authority check for a stable event name."""
        with self._lock:
            if event_name in self._protectors:
                raise ValueError(f"Event already protected: {event_name}")
            self._protectors[event_name] = validator

    def publish(self, event: Event) -> Event:
        validator = self._protectors.get(event.name)
        if validator is not None:
            allowed, reason = validator(event)
            if not allowed:
                self._append(
                    Event(
                        name="ProtectedEventRejected",
                        source="event_bus",
                        cycle=event.cycle,
                        payload={
                            "rejected_event_id": event.event_id,
                            "rejected_event_name": event.name,
                            "rejected_source": event.source,
                            "reason": reason,
                        },
                    )
                )
                raise EventRejected(reason)
        self._append(event)
        with self._lock:
            handlers = list(self._subscribers.get(event.name, [])) + list(self._subscribers.get("*", []))
        for handler in handlers:
            try:
                handler(event)
            except Exception as exc:  # event consumers may not stop the kernel
                self._append(Event(
                    name="SubscriberFailed",
                    source="event_bus",
                    cycle=event.cycle,
                    payload={"event_id": event.event_id, "event_name": event.name, "error": str(exc)[:1000]},
                ))
        return event

    def emit(self, name: str, payload: dict[str, Any], *, source: str = "void_os", cycle: int | None = None) -> Event:
        return self.publish(Event(name=name, payload=payload, source=source, cycle=cycle))

    def replay(self, event_name: str | None = None, limit: int | None = None) -> list[Event]:
        rows: list[Event] = []
        try:
            lines = self.log_path.read_text(encoding="utf-8").splitlines()
        except OSError:
            return rows
        if limit is not None:
            lines = lines[-max(0, int(limit)):]
        for line in lines:
            try:
                data = json.loads(line)
                event = Event(**data)
                if event_name is None or event.name == event_name:
                    rows.append(event)
            except (TypeError, ValueError):
                continue
        return rows

    def _append(self, event: Event) -> None:
        with self._lock:
            with self.log_path.open("a", encoding="utf-8") as handle:
                handle.write(json.dumps(asdict(event), ensure_ascii=False, sort_keys=True) + "\n")
