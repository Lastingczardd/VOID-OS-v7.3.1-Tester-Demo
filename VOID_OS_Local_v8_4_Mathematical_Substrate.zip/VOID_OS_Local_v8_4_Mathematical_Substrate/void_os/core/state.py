"""Atomic structured project state for reproducible autonomous cycles."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any


class ProjectStateStore:
    def __init__(self, state_root: Path):
        self.path = Path(state_root) / "project_state.json"
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def load(self) -> dict[str, Any]:
        try:
            value = json.loads(self.path.read_text(encoding="utf-8"))
            return value if isinstance(value, dict) else {}
        except (OSError, ValueError):
            return {}

    def update(self, **changes: Any) -> dict[str, Any]:
        """Compatibility update for non-promotional operational fields only."""
        forbidden = {"last_decision", "last_vis", "predictive", "promotion", "accepted"}
        if forbidden.intersection(changes):
            raise PermissionError("Promotion state requires a receipted GovernorDecision.")
        return self._write(changes)

    def apply_governor_decision(
        self, changes: dict[str, Any], *, constitutional_receipt: str
    ) -> dict[str, Any]:
        if len(str(constitutional_receipt)) != 64:
            raise PermissionError("A valid constitutional receipt is required.")
        return self._write({**changes, "constitutional_receipt": constitutional_receipt})

    def _write(self, changes: dict[str, Any]) -> dict[str, Any]:
        state = self.load()
        state.update(changes)
        temp = self.path.with_suffix(".json.tmp")
        temp.write_text(json.dumps(state, indent=2, ensure_ascii=False, sort_keys=True), encoding="utf-8")
        temp.replace(self.path)
        return state
