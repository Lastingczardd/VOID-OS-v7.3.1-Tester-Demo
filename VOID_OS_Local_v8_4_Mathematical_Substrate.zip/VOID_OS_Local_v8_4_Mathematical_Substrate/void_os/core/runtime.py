"""Wires the v8 event stream to durable projections."""
from __future__ import annotations

from pathlib import Path

from .events import EventBus
from .state import ProjectStateStore
from ..knowledge.graph import EngineeringKnowledgeGraph
from ..portfolio.engineering import EngineeringPortfolio
from ..orchestra.builder import BuilderOrchestra
from ..governance.event_gateway import ConstitutionalEventGateway


class EngineeringRuntime:
    def __init__(self, state_root: Path, agents=None, config=None):
        self.state_root = Path(state_root)
        self.config = config
        self.bus = EventBus(self.state_root)
        self.state = ProjectStateStore(self.state_root)
        self.knowledge = EngineeringKnowledgeGraph(self.state_root)
        self.portfolio = EngineeringPortfolio(self.state_root)
        self.governance = ConstitutionalEventGateway(self.bus, self.state, self.state_root)
        self.bus.subscribe("*", self.knowledge.consume)
        self.bus.subscribe("GovernorDecision", self.portfolio.consume)
        if self.config is not None:
            self.bus.subscribe("GovernorDecision", self._sync_config_head)
        self.orchestra = BuilderOrchestra(agents, self.bus) if agents is not None else None

    def set_operational_state(self, **changes):
        """Record non-promotional runtime status."""
        return self.state.update(**changes)

    def request_governor_decision(
        self,
        report,
        *,
        cycle,
        builder_goal_id=None,
        state_changes=None,
    ):
        """Request state advancement through the event-driven constitutional gate."""
        return self.governance.request_governor_decision(
            report,
            cycle=cycle,
            builder_goal_id=builder_goal_id,
            state_changes=state_changes,
        )

    def _sync_config_head(self, event):
        if not event.payload.get("accepted"):
            return
        active = event.payload.get("state_changes", {}).get("active_project")
        if not active:
            return
        self.config["active_project"] = active
        self.config.pop("working_project", None)
        from ..kernel.config import save

        save(self.config)
