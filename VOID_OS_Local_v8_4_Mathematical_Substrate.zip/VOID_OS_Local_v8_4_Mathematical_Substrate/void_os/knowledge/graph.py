"""Lightweight append-only engineering knowledge graph projection."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

from ..core.events import Event


class EngineeringKnowledgeGraph:
    def __init__(self, state_root: Path):
        self.path = Path(state_root) / "engineering_knowledge_graph.jsonl"
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def consume(self, event: Event) -> None:
        if event.name not in {
            "OpportunityDiscovered",
            "EngineeringClaimed",
            "ImplementationStarted",
            "ImplementationFinished",
            "OrchestraPlanned",
            "OrchestraFinished",
            "SpecialistFinished",
            "VerificationFinished",
            "ValueEvaluated",
            "GovernorDecision",
            "KnowledgeRecorded",
            "RealityAuditFinished",
        }:
            return
        payload = event.payload
        subject = str(payload.get("fingerprint") or payload.get("task") or payload.get("problem") or event.event_id)
        node_id = hashlib.sha256(subject.encode("utf-8", errors="replace")).hexdigest()[:20]
        row = {
            "node_id": node_id,
            "kind": event.name,
            "cycle": event.cycle,
            "event_id": event.event_id,
            "source": event.source,
            "payload": payload,
            "created_at": event.created_at,
        }
        with self.path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n")
