@echo off
setlocal
cd /d "%~dp0"
python -m void_os.math_kernel.dashboard
if errorlevel 1 (
  echo.
  echo VOID OS mathematical dashboard exited with an error.
  pause
)
