# VOID OS v8.3 Covenant and Continuity Beta

## Added

- Enforceable lifecycle rules for retention, deletion, backups, derived data,
  training material, embeddings, third-party copies, and deletion proof.
- Accountable practicality decisions; service operators cannot exempt
  themselves.
- Proportional assistance that cannot force tutorials or excessive cognitive
  labor.
- Disclosed, bounded, consent-respecting interaction learning with opt-out.
- Provenanced, correctable, exportable consequential memory.
- Notice and renewed consent for identity-bearing configuration changes.
- Honest representation of absent or unverified continuity.
- Relational Covenant prohibiting dependency engineering, care-as-control,
  coerced interaction, false equivalence, and blocked departure.
- Nine new denial-path and permission-path tests.

## Preserved

- The fourteen immutable clauses and all v8.2 constitutional gates.
- Builder Rights, Civic Immune Monitor, VIE/PVIE separation, Governor-only
  promotion, staged candidates, hash-chained ledgers, rollback, local-first
  operation, and disabled generated-code execution.

