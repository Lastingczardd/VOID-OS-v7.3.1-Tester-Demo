# VOID OS Φ∞ v8.4 — Mathematical Substrate

## Added

- Integrated the Φ∞ mathematical kernel as `void_os.math_kernel`.
- Added deterministic null-state transitions and normalization without erasure.
- Added polarity, ternary deepening, cube-root folding, digital roots, Tetractys,
  triangular transforms, and fold-invariant verification.
- Added Reality Veto and Continuous Will policy layers.
- Added a dedicated append-only SQLite ledger with SHA-256 event chaining.
- Added local CLI shell and Tkinter mathematical dashboard.
- Added isolated subsystem verification and five integration tests.
- Added an explicit boundary separating symbolic correspondences from empirical claims.

## Preserved

- Existing `void_os.kernel` security, path, witness, and configuration package.
- All v8.3.1 constitutional, evidence, continuity, orchestra, and release safeguards.
- Generated-code execution remains disabled by default.
