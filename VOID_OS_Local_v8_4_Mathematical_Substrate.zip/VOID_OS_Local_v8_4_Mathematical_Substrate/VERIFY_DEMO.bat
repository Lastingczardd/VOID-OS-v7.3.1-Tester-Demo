@echo off
setlocal
cd /d "%~dp0"
py -3 VERIFY_DEMO.py 2>nul || python VERIFY_DEMO.py
if errorlevel 1 pause
