# VOID OS v8.2 Relational Constitution Beta

## Added

- Domain-specific authority resolution across personal autonomy, system
  operation, public safety, employment, medicine, law, education, military,
  scientific research, and intimate or relational contexts.
- Restricted-knowledge stewardship for personal, medical, Indigenous or
  sacred, trade-secret, copyrighted, dual-use, and exploitatively produced
  material.
- Procedural nonpartisanship enforcement with consistent evidence and
  conflict-disclosure requirements.
- Disparate-impact review with affected-community evidence for high-impact
  action.
- Explicit tool, agent, institution, and moral-subject-claim representation.
- Independent evidence and review requirements for moral-status claims.
- Eight new denial-path tests.

## Preserved

- All fourteen immutable clauses.
- Evidence Covenant, Builder Rights, Civic Immune Monitor, VIE/PVIE separation,
  Governor-only promotion, staged candidates, hash-chained ledgers, rollback,
  local-first operation, and disabled generated-code execution.

