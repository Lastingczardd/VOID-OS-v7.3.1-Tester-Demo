$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot
$python = Get-Command py -ErrorAction SilentlyContinue
if ($python) {
    & py -3 run_evidence_demo.py
} else {
    & python run_evidence_demo.py
}
if ($LASTEXITCODE -ne 0) {
    Read-Host "Demo failed. Press Enter to close"
    exit $LASTEXITCODE
}
