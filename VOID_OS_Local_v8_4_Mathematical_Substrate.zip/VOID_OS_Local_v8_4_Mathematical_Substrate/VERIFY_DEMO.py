"""Compile, test, and verify the packaged v8.3 beta."""
from __future__ import annotations

import compileall
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main() -> int:
    print("1/4 Compile Python")
    if not compileall.compile_dir(ROOT, quiet=1):
        return 1
    print("2/4 Run unit tests")
    tests = subprocess.run(
        [sys.executable, "-m", "unittest", "discover", "-s", "tests", "-v"],
        cwd=ROOT,
        check=False,
    )
    if tests.returncode:
        return tests.returncode
    print("3/4 Run headless covenant cycle")
    with tempfile.TemporaryDirectory() as temporary:
        demo = subprocess.run(
            [sys.executable, "run_evidence_demo.py", "--no-open", "--output", temporary],
            cwd=ROOT,
            check=False,
        )
        if demo.returncode:
            return demo.returncode
    print("4/4 Verify packaged core manifest")
    from void_os.kernel.security import verify_core_manifest

    ok, message = verify_core_manifest()
    print(("PASS: " if ok else "FAIL: ") + message)
    if ok:
        print("ALL DEMO CHECKS PASSED")
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
