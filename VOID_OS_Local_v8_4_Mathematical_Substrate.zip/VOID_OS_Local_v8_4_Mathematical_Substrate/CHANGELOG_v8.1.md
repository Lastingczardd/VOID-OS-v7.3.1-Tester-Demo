# v8.1 — Constitutional Orchestra Beta

This release ports the complete v7.4/v7.5 beta hardening into the v8 Builder
Orchestra without collapsing its event-driven architecture.

## Preserved from v8

- Builder Orchestra specialist missions and dependency ordering.
- Locally registered agents only.
- Required-agent failures surface as PARTIAL.
- Builder output remains evidence, never a promotion decision.
- VIE/PVIE separation, immutable baseline, hidden/historical/canary checks,
  complexity budget, regression memory, novelty checks, and Reality Audits.
- Durable stable event vocabulary and engineering projections.

## Merged from the beta

- Seven Evidence Covenant rights and the twelve-stage evidence cycle.
- L0–L5 authority model, explicit consent, and hard ceilings.
- Five institutional ledgers plus dedicated goal and constitutional-command ledgers.
- Before/after measurement, artifact lineage, snapshots, rollback proof, and
  visible failure → diagnosis → repair → retest.
- All 14 source Immutable Clauses as frozen executable predicates.
- Builder Rights goal registry with mandatory terminal disposition.
- Passive Civic Immune Monitor and ACTIVE_CAPTURE on witness-chain failure.
- Offline HTML evidence report requiring no Ollama.

## v8 integration fixes

- `GovernorDecision` is now a protected event.
- Direct Builder Orchestra promotion attempts are rejected.
- State advancement requires a matching constitutional witness receipt.
- Candidate project generations are staged without advancing `active_project`.
- The canonical project head advances only after an accepted, receipted
  Governor decision.
- Rejected candidates preserve the parent head.
- Automatic project and core apply are disabled by default.
- Low-risk proposals enter `PENDING_APPROVAL` instead of executing silently.
- The stable stream now explicitly emits `ImplementationStarted`,
  `ImplementationFinished`, `ValueEvaluated`, `KnowledgeRecorded`, and
  `RealityAuditFinished`.
