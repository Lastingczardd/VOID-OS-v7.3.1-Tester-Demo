@echo off
setlocal
cd /d "%~dp0"
python -m void_os.math_kernel.cli shell
if errorlevel 1 (
  echo.
  echo VOID OS mathematical kernel exited with an error.
  pause
)
