@echo off
setlocal
cd /d "%~dp0"
python -m unittest tests.test_math_kernel_subsystem -v
pause
