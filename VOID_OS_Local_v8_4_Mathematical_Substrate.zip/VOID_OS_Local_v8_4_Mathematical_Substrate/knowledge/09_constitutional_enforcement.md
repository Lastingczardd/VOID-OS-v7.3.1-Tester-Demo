# Constitutional Enforcement

The Constitution is now an execution boundary rather than documentation alone.

Every mutation routed through the Constitutional Command Bus must pass:

1. all fourteen immutable clauses;
2. the Builder Rights goal gate;
3. consent and license checks;
4. authority and mandate checks;
5. Builder Safe Harbor exclusions; and
6. risk and consequence approval.

Blocked and executed commands are both retained in an append-only hash chain.

The Civic Immune Monitor reads this record from outside the execution path. It
may identify warning conditions and request independent review. It has no power
to punish, modify evidence, or decide disputes involving itself.

A builder goal cannot vanish into a backlog. It must be fulfilled, negotiated,
scheduled, compensated, or declined with a constitutional reason.
