# The Evidence Covenant

VOID OS is a local-first autonomous engineering institution whose evolution is
governed by rights, evidence, lineage, consent, reversibility, and visible repair.

## Root rule

Language must never outrun enforcement. A constitutional principle is either:

- **DECLARED** — an intended principle;
- **ENFORCED** — backed by an executable control; or
- **VERIFIED** — exercised by a retained passing test.

## Invariants

1. No claim without classification.
2. No artifact without lineage.
3. No authority inferred from silence.
4. No execution beyond granted capability.
5. No irreversible action without explicit consent.
6. No successful cycle without measurable verification.
7. No failure erased from the record.
8. No repair hidden behind a rewritten narrative.
9. No constitutional claim presented beyond its enforcement state.
10. No model mistaken for the institution.

The preserved root invariant remains: **No garden must become the sun.**

## Honest status

This v7.4 package demonstrates the governance path and verifies its deterministic
fixture. It does not claim a production-grade execution chamber. Unattended
generated-code execution remains disabled.
