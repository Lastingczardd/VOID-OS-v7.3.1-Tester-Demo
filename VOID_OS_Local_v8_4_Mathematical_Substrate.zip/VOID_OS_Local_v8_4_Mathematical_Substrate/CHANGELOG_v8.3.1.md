# VOID OS v8.3.1 Release Hardening

## Added

- One-command `RELEASE_CHECK.bat` release gate for Windows.
- Deterministic compile, unit-test, offline-cycle, security, JSON, and package checks.
- Canonical clean ZIP generation that excludes caches, virtual environments,
  previous archives, and runtime demo output.
- Required-file validation before a public package can be produced.

## Verified

- 43 constitutional, evidence, orchestra, engineering, value-integrity, and
  living-cycle tests pass.
- The offline evidence cycle runs without Ollama.
- Core-manifest integrity is checked before release packaging.

## Unchanged boundaries

- Generated-code execution remains disabled.
- Automatic project apply and automatic core apply remain disabled.
- Builder output still requires constitutional and Governor authorization.
